# Arquitectura de la suite

La suite utiliza una arquitectura de **federación modular**: un orquestador pequeño coordina módulos independientes y un registro describe el corpus. Esto reduce el coste de contexto y evita que una modificación transversal rompa una habilidad especializada.

## Precedencia

1. Requisitos explícitos de la petición.
2. Políticas de seguridad y permisos.
3. Habilidad especializada de mayor especificidad.
4. Habilidades de soporte estrictamente necesarias.
5. Orquestador raíz para coordinación, trazabilidad y entrega.

## Ciclo operativo

```mermaid
flowchart TD
 A[Petición] --> B[Definir alcance y riesgos]
 B --> C[Consultar registry.json]
 C --> D[Seleccionar módulo específico]
 D --> E[Leer referencias necesarias]
 E --> F[Ejecutar con permisos mínimos]
 F --> G[Validar salida]
 G --> H[Entregar evidencia, límites y rollback]
```

## Compatibilidad

Los nombres y rutas de los módulos se conservan. Las mejoras de la distribución se concentran en el orquestador, el registro, los validadores y la documentación para no cambiar silenciosamente el comportamiento de las habilidades heredadas.

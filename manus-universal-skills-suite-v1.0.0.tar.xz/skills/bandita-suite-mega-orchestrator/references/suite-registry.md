# Registro de la suite

La suite contiene 6 mega habilidades, 15 habilidades normales y 28 subhabilidades. Leer este registro para seleccionar la unidad mínima necesaria.

## Regla de selección

Activar la mega habilidad sólo cuando el encargo abarque varias capas. Para tareas concretas, cargar una habilidad normal y sus subhabilidades directas. Conservar siempre evidencia, límites y procedencia.

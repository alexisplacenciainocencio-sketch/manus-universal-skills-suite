# Grafo de dependencias

```text
mega-orchestrator
├── mega-evidence-catalog
│   ├── normal-source-discovery
│   ├── normal-evidence-ledger
│   ├── normal-link-verification
│   └── normal-catalog-enrichment
├── mega-community-publishing
│   ├── normal-community-formatting
│   ├── normal-accessibility
│   └── normal-tutorials-faq-maps
├── mega-regional-localization
│   ├── normal-regionalization
│   └── normal-deduplication
├── mega-governance-security
│   ├── normal-foundation-discernment
│   ├── normal-ai-governance
│   └── normal-security-ci
└── mega-release-ops
    ├── normal-historical-preservation
    └── sub-manifest-sha-generation → sub-sevenzip-extraction-gate
```

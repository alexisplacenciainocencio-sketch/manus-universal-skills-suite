# Contratos reutilizables

## Contrato de identidad

Una identidad se define por URL canónica, organización, repositorio y naturaleza. Un fork, espejo, upstream o distribución separada puede requerir una identidad independiente.

## Contrato de evidencia

Cada afirmación debe conservar fuente, fecha, valor observado, método y certeza. Declarado por README no equivale a verificado por prueba independiente.

## Contrato regional

Las variantes es-DO y en-US comparten rutas, URLs, versiones, estados, hashes, controles y conteos; sólo se localiza la capa editorial.

## Contrato de release

El release exige copia de trabajo, corpus histórico preservado, validación estructural, lint, manifest sin autorreferencia, 7z, `7z t`, extracción temporal y comparación SHA-256.

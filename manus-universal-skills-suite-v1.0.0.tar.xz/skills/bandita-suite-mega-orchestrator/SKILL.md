---
name: bandita-suite-mega-orchestrator
description: "Orquestar el flujo completo de la Bandita para investigar, verificar, enriquecer, publicar, localizar, gobernar, auditar y empaquetar catálogos Open Sauce. Usar cuando el encargo abarque varias capas o pida una actualización integral bilingüe y reproducible."
---

# Orquestador de la Bandita

Activar esta mega habilidad cuando el encargo necesite coordinar investigación, catálogo, publicación, localización, seguridad y release. La suite contiene **6 mega habilidades**, **15 habilidades normales** y **28 subhabilidades**. No cargar todo por defecto en tareas pequeñas: seleccionar la unidad mínima que cubra el objetivo.

## Flujo obligatorio

1. Definir alcance, fecha/hora de corte, corpus de entrada, categorías, nivel de evidencia y salida solicitada.
2. Congelar la base en una copia de trabajo y registrar rutas, tamaños, hashes, históricos, registros, scripts y controles.
3. Investigar fuentes primarias. Tratar wikis, buscadores, directorios y changelogs como descubrimiento hasta verificar cada recurso en su fuente original.
4. Enriquecer cada identidad con naturaleza, función, encaje, preparación, evolución, licencia, riesgos, permisos, enlaces y rollback.
5. Deduplicar por identidad y URL canónica. Mantener forks, upstreams, fuentes, índices, compilados y assets separados cuando su función o procedencia sea distinta.
6. Construir variantes es-DO y en-US con las mismas rutas, URLs técnicas, versiones, estados, hashes, controles y conteos. Localizar sólo la capa editorial.
7. Aplicar mínimo privilegio, lint de seguridad, control de secretos, rutas, symlinks, permisos, artefactos y CI/CD. No descargar ni ejecutar APK, JAR, rootfs, binarios o código no confiable.
8. Generar publicación humana y accesible con contexto, separadores, mapa, FAQ, memes pedagógicos y emojis moderados sólo cuando el canal lo permita.
9. Validar estructura, evidencia, equivalencia, manifest SHA-256 y 7z. Ejecutar `7z t`, extraer en temporal y comparar hashes por entrada.
10. Entregar archivos, evidencias, hashes exteriores y límites. Declarar cualquier corte parcial, conflicto o revisión humana pendiente.

## Mapa de la suite

| Nivel | Cantidad | Función |
|---|---:|---|
| Mega habilidades | 6 | Coordinar áreas amplias del flujo |
| Habilidades normales | 15 | Resolver dominios reutilizables |
| Subhabilidades | 28 | Ejecutar operaciones estrechas y deterministas |

Las seis mega habilidades son `orchestrator`, `evidence-catalog`, `community-publishing`, `regional-localization`, `governance-security` y `release-ops`. El catálogo completo, dependencias y salidas están en `references/suite-registry.md`, `references/suite-registry.json` y `references/dependency-graph.md`.

## Decisiones críticas

**¿La novedad tiene fuente primaria y fecha?** Si no, marcarla como candidata pendiente. **¿La URL es una ruta técnica?** Copiarla literalmente; no inventar nombres de índice, ramas o assets. **¿Es un fork o una continuación?** Mapear la relación y conservar la identidad cuando la función, mantenedor o distribución cambien. **¿Requiere Root, Shizuku, Dhizuku, ADB o cookies?** Añadir advertencia, mínimo privilegio, copia y rollback. **¿Las variantes difieren en rutas?** Detener el release. **¿La licencia o seguridad es incierta?** Declararlo y no convertir la incertidumbre en recomendación.

## Contrato de salida

La salida debe conservar procedencia, certeza, límites y trazabilidad. Una publicación pública no debe exponer tokens, cookies, credenciales, rutas privadas ni metacomentarios internos. Una capa de control sí puede registrar validaciones, hashes, errores, límites API y decisiones de release.

## Rendimiento y automatización

Usar perfiles `fast`, `verify` y `release` sólo cuando estén disponibles y documentar qué cubre cada uno. Mantener cachés fuera del árbol publicable. No activar schedules, polling, hosting persistente, publicación remota ni sincronización total sin autorización explícita y credencial válida.

## Referencias directas

- `references/suite-registry.md`: inventario y selección.
- `references/contracts.md`: identidad, evidencia, regionalización y release.
- `references/dependency-graph.md`: orden de carga y dependencias.

## Condición de parada

Detenerse y pedir aclaración cuando el alcance no defina qué significa “actualizado”, cuando una fuente no sea comprobable, cuando el corpus histórico esté incompleto, cuando aparezcan secretos o artefactos peligrosos, o cuando el usuario solicite publicar/modificar servicios externos sin autorización explícita.

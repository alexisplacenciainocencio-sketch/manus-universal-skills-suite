# Integración CI/CD

## Diseño seguro

El runner `scripts/ci_security_lint.py` funciona después de que el proveedor haya hecho checkout del repositorio. No usa red, no ejecuta comandos mediante shell y no envía credenciales. Invoca el linter como una lista de argumentos con `subprocess.run(..., shell=False)` y devuelve el mismo código de salida del linter: `0` para éxito, `1` para hallazgos y `2` para configuración inválida.

En GitHub Actions usar `pull_request`, no `pull_request_target`, para código no confiable. Declarar `permissions: contents: read`, no exponer secretos al job y fijar versiones o SHA de las acciones según la política del proyecto. Subir los informes como artefactos sólo si la política del repositorio lo permite.

## Ejemplo mínimo de GitHub Actions

Copiar `scripts/lint_security.py` y `scripts/ci_security_lint.py` a `.bandita/` del repositorio y usar:

```yaml
name: Bandita security lint

on:
  push:
  pull_request:

permissions:
  contents: read

jobs:
  security-lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - name: Run static security lint
        run: >-
          python .bandita/ci_security_lint.py
          --repo-root .
          --linter .bandita/lint_security.py
          --scan-path src
          --scan-path scripts
          --report .bandita-artifacts/security-lint.json
      - name: Upload lint report
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: bandita-security-lint
          path: .bandita-artifacts/
```

El ejemplo falla el job cuando el linter encuentra un hallazgo. Para proyectos que no usan `src`, repetir `--scan-path` con las carpetas reales. Para revisar sólo un archivo, pasar `--scan-path path/to/file.py`.

## Configuración JSON

El runner acepta un archivo de configuración. Los argumentos explícitos tienen prioridad sobre el archivo; el archivo tiene prioridad sobre las variables de entorno; los valores por defecto se aplican al final.

```json
{
  "repo_root": ".",
  "linter": ".bandita/lint_security.py",
  "scan_paths": ["src", "scripts"],
  "report": ".bandita-artifacts/security-lint.json",
  "allow_symlinks": false,
  "allow_world_writable": false
}
```

Usarlo con `python .bandita/ci_security_lint.py --config .bandita/ci-security.json`. Las opciones `allow_symlinks` y `allow_world_writable` deben reservarse para excepciones justificadas y revisadas; el modo estricto es el predeterminado.

## Variables de entorno

Se pueden usar `BANDITA_REPO_ROOT`, `BANDITA_LINTER`, `BANDITA_SCAN_PATHS`, separado por el separador de rutas del sistema, y `BANDITA_REPORT`. No guardar tokens, cookies ni claves en estas variables ni en el archivo JSON.

## Otros proveedores

En GitLab CI, Azure Pipelines o Jenkins, ejecutar el mismo comando después del checkout y publicar `.bandita-artifacts/` como artefacto del job. El runner es independiente del proveedor; sólo requiere Python 3.10 o posterior y los scripts locales. Mantener la ejecución en un job sin permisos de escritura sobre el repositorio.

## Personalización segura

Personalizar rutas y nombre del informe; no desactivar controles para ocultar hallazgos. Si un repositorio necesita una excepción, documentar el motivo, el propietario, la fecha de revisión y el alcance mínimo. Para controles adicionales, ejecutar `ruff`, `bandit`, `pip-audit` o un escáner de secretos separado en jobs independientes y conservar sus resultados.

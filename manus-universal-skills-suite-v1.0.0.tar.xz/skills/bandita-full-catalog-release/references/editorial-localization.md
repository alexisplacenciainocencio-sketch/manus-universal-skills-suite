# Localización editorial y preservación histórica

La localización se aplica primero a la capa vigente: títulos, introducciones, descripciones, FAQ, advertencias, recomendaciones y convenciones regionales. La variante `do` debe usar español dominicano natural y la variante `us`, inglés estadounidense claro. Mantener el mismo orden conceptual, campos, categorías, estados y cobertura.

No traducir nombres propios de proyectos, repositorios, organizaciones, ramas, versiones, asset names, URLs, hashes, identificadores ni rutas técnicas. Las cuatro categorías de enlace deben conservar los mismos valores cuando describen el mismo recurso.

Los materiales históricos, entradas recibidas y publicaciones antiguas se conservan para trazabilidad y rollback. Si contienen otro idioma, errores o decisiones obsoletas, no reescribirlos silenciosamente. Clasificarlos como histórico/entrada y evitar que parezcan recomendación vigente.

Cada resumen regional debe declarar: fecha de corte, número de archivos, número de entradas del manifest, tamaño sin comprimir, tamaño del contenedor, equivalencia de rutas, alcance de la traducción y cualquier contenido histórico preservado literalmente. Una variante regional puede diferir en bytes por idioma sin diferir en inventario ni estructura.

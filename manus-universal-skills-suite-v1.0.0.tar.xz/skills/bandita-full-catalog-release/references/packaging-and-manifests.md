# Empaquetado y manifests

## Manifest

Generar rutas relativas ordenadas y SHA-256 por archivo. Excluir el manifest que se está creando y cualquier archivo cuyo nombre empiece por `validation_` y termine en `.json`, incluso dentro de subdirectorios. Los informes excluidos permanecen dentro del archivo comprimido; la exclusión evita autorreferencia y permite repetir la operación.

Formato recomendado por línea:

```text
<sha256>  <ruta/relativa>
```

No usar rutas absolutas. Registrar por separado el número de entradas del manifest, el número total de archivos del árbol y la razón de la diferencia.

## 7z

Usar:

```bash
7z a -t7z -mx=9 -m0=lzma2 -md=64m -mmt=on -ms=on salida.7z nombre_del_arbol
7z t salida.7z
7z x -y salida.7z -o/tmp/release-extract
```

Tras extraer, comparar la lista de rutas y el SHA-256 de todos los archivos incluidos por el manifest. Informar `missing`, `extra` y `hash_mismatches`; el release sólo es íntegro cuando los tres están vacíos y `7z t` devuelve éxito. Calcular además SHA-256 exterior del contenedor.

## ZIP

Usar nombres UTF-8 y probar con `unzip -tq`. Aplicar la misma comparación de rutas y hashes. No presentar el tamaño comprimido como sustituto del alcance: un archivo puede comprimir mucho por duplicación, texto o archivos internos.

## Entrega

Adjuntar el contenedor, el resumen, los manifests distinguidos por variante y los informes JSON de alcance, auditoría y empaquetado. Nunca entregar sólo el archivo comprimido sin checksum, conteo y límites.

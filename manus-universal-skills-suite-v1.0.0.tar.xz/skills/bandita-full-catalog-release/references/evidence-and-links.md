# Evidencia y enlaces técnicos

## Jerarquía

Priorizar repositorio oficial, README, documentación y release. Usar después el perfil del mantenedor, registro de paquete o documentación de plataforma; luego API y metadatos estructurados; finalmente wikis, directorios, foros, vídeos o publicaciones comunitarias como descubrimiento que requiere confirmación.

## Estados recomendados

Usar `Confirmado` cuando una fuente primaria sostiene la afirmación; `Declarado por el proyecto` cuando el README lo afirma sin comprobación adicional; `Verificado por metadatos` para rama, release, archivado o licencia obtenidos estructuradamente; `Descubrimiento comunitario` para una pista secundaria; `Necesita revisión` ante datos incompletos o conflictivos; `Archivado o legado` sólo cuando la fuente primaria lo respalda; y `No localizado` cuando no se encuentra evidencia funcional.

## Cuatro enlaces

| Campo | Significado | Regla |
|---|---|---|
| `developer_maintainer` | Persona, organización o perfil responsable | No sustituirlo por el repositorio del producto |
| `update_channel` | Discord, Matrix, Telegram, foro, blog o web | Incluir sólo si se localiza y comprueba |
| `repository_or_primary_source` | Repositorio o fuente primaria exacta | Conservar rama y organización correctas |
| `direct_distribution` | APK, asset, índice JSON, snapshot o paquete | Verificar ruta real; no construirla por patrón |

Para extensiones, consultar primero la rama declarada y listar sus archivos reales. `index.min.json`, `index.json`, `repo`, `releases/latest` y `raw` no son rutas universales. Si no existe un archivo funcional, escribir literalmente `No se encontró enlace directo verificable` y conservar la ruta primaria.

## Correcciones

Cuando una ruta recibida falla, registrar URL original, código observado, fuente primaria consultada, URL corregida, fecha y estado. No ocultar la corrección ni presentar una redirección como prueba de continuidad del proyecto.

# Linting estático y seguridad de scripts

## Propósito

El linter complementa, pero no sustituye, la revisión humana ni el análisis de dependencias. Se ejecuta sobre los scripts propios de la habilidad, no sobre código recibido dentro de catálogos o materiales históricos.

## Controles incluidos

| Control | Resultado de fallo |
|---|---|
| `py_compile` | Error: el script no es sintácticamente ejecutable |
| AST de imports peligrosos | Error: `pickle`, `marshal`, `dill` o `telnetlib` requieren revisión explícita |
| AST de llamadas dinámicas | Error: `eval`, `exec`, `compile` o `__import__` |
| Comandos del sistema | Error: `os.system`, `os.popen` o `subprocess(..., shell=True)` |
| Patrones de secretos | Error: claves privadas, tokens GitHub/Slack o asignaciones de claves con valores literales largos |
| Symlinks en la habilidad | Error: evita redirecciones no auditadas de archivos |
| Archivos escribibles por cualquiera | Error: previene modificación no controlada de scripts o plantillas |

## Uso

```bash
python3 scripts/lint_security.py /ruta/a/la/habilidad /ruta/a/security_lint.json
```

El informe JSON contiene `ok`, scripts comprobados, resultados de compilación, reglas y hallazgos. Un informe correcto tiene `ok: true`, todos los elementos de `compile` con `ok: true` y `findings: []`.

## Interpretación

Un hallazgo puede ser un falso positivo si el texto forma parte de una regla, una prueba o documentación. No eliminar el control para silenciarlo: revisar la línea, sustituir la construcción insegura o registrar una excepción justificada en el código y en el informe. El linter no demuestra que un token no exista, no revisa vulnerabilidades de dependencias, no prueba comportamiento en runtime y no garantiza que un archivo histórico sea seguro.

## Complementos recomendados

Cuando estén disponibles, ejecutar también `ruff check`, `bandit`, `pip-audit` y un escáner de secretos en modo sólo lectura. Mantener estas herramientas opcionales porque el flujo base debe funcionar en una instalación limpia con la biblioteca estándar. No instalar paquetes ni ejecutar código encontrado en el catálogo sólo para satisfacer un lint.

## Límites operativos

El linter debe inspeccionar únicamente rutas explícitas dentro de la habilidad. No abrir conexiones de red, no descargar dependencias, no ejecutar scripts auditados y no modificar archivos salvo el informe indicado. La validación del contenido del catálogo, de las URL y del archivo 7z permanece en los validadores separados.

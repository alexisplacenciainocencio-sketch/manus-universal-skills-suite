# Invariantes del release integral

## Capas

El árbol final debe distinguir tres capas: **vigente**, **histórica/entrada** y **control/reproducibilidad**. La capa vigente contiene la publicación, catálogo, fichas y estados actuales. La capa histórica conserva el material heredado sin vaciarlo. La capa de control contiene manifests, validaciones, scripts, inventarios y resúmenes.

## Equivalencia entre variantes

Para `do` y `us`, comparar siempre la lista completa de rutas relativas. Los nombres técnicos deben ser comunes: repositorios, ramas, versiones, asset names, URLs, identificadores y archivos de control. Los textos editoriales de la capa vigente sí pueden diferir por idioma y convención regional. El material histórico puede permanecer literalmente en el idioma recibido si se declara en el resumen.

## Conteos

Registrar antes y después de la superposición: archivos totales, bytes, archivos históricos, registros del catálogo, fichas especializadas, ramas, URLs técnicas y archivos de control. Nunca prometer un conteo de recursos si sólo se contó el número de líneas o campos modificados.

## Evidencia de contenido

Cada actualización debe incluir fecha de corte y procedencia. Para estados conflictivos, conservar la señal primaria y la secundaria, indicar la discrepancia y no resolverla mediante una inferencia. “Disponible” sólo significa que una ruta respondió o fue observada; no significa seguro, compatible, autorizado o continuo.

## Rollback

La base histórica nunca se modifica. El overlay y los árboles regionales deben poder reconstruirse desde rutas declaradas. Conservar hashes, inventarios, correcciones de enlace y versiones anteriores dentro de la capa de control.

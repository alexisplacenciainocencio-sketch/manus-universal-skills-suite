# Seguridad y rollback

No incluir credenciales, cookies, tokens, sesiones, claves privadas, archivos `.env`, bibliotecas privadas ni datos personales. Buscar marcadores obvios (`ghp_`, `github_pat_`, `xoxb-`, claves PEM y asignaciones de API keys), pero tratar el escáner como ayuda y no como prueba absoluta.

No ejecutar scripts, APKs, módulos, binarios o instaladores encontrados en materiales recibidos. No evadir DRM, CAPTCHA, paywalls, licencias, restricciones de acceso ni controles de plataforma. No recomendar APKs desconocidas ni enlaces de distribución que no estén respaldados por la fuente primaria.

Para root, Magisk, KernelSU, APatch, Shizuku, ADB, Device Owner o automatización, registrar permisos, arquitectura, minSdk/SDK objetivo cuando existan, dependencia, copia de seguridad, orden de reversión y riesgos. Separar compatibilidad declarada de compatibilidad probada. Recomendar sólo permisos mínimos y supervisión humana.

Antes de modificar un release, crear una copia de trabajo y calcular hashes de la base. Mantener la base anterior intacta. Guardar el overlay, el script de construcción, el inventario, el manifest, el informe de validación y el hash exterior del archivo comprimido para poder reconstruir o revertir el resultado.

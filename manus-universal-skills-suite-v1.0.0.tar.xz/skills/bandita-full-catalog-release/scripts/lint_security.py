#!/usr/bin/env python3
"""Run static safety and lint checks over the skill's Python scripts."""
from __future__ import annotations

import argparse
import ast
import json
import re
import stat
import subprocess
import sys
from pathlib import Path

SECRET_PATTERNS = {
    "private_key": re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    "github_token": re.compile(r"(?:ghp_|github_pat_)[A-Za-z0-9_]{20,}"),
    "slack_token": re.compile(r"xox[baprs]-[A-Za-z0-9-]{16,}"),
    "api_key_assignment": re.compile(r"(?i)(?:api[_-]?key|secret[_-]?key|access[_-]?token)\s*[:=]\s*['\"][A-Za-z0-9+/=_-]{16,}['\"]"),
}
DANGEROUS_CALLS = {"eval", "exec", "compile", "__import__"}
DANGEROUS_IMPORTS = {"pickle", "marshal", "dill", "telnetlib"}

def source_findings(path: Path) -> list[dict]:
    findings = []
    text = path.read_text(encoding="utf-8", errors="strict")
    for name, pattern in SECRET_PATTERNS.items():
        if pattern.search(text):
            findings.append({"severity": "error", "rule": f"secret:{name}", "file": str(path)})
    try:
        tree = ast.parse(text, filename=str(path))
    except SyntaxError as exc:
        return findings + [{"severity": "error", "rule": "syntax-error", "file": str(path), "line": exc.lineno, "message": str(exc)}]
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.split(".")[0] in DANGEROUS_IMPORTS:
                    findings.append({"severity": "error", "rule": "dangerous-import", "file": str(path), "line": node.lineno, "message": alias.name})
        elif isinstance(node, ast.ImportFrom) and node.module and node.module.split(".")[0] in DANGEROUS_IMPORTS:
            findings.append({"severity": "error", "rule": "dangerous-import", "file": str(path), "line": node.lineno, "message": node.module})
        elif isinstance(node, ast.Call):
            name = node.func.id if isinstance(node.func, ast.Name) else node.func.attr if isinstance(node.func, ast.Attribute) else ""
            if isinstance(node.func, ast.Name) and name in DANGEROUS_CALLS:
                findings.append({"severity": "error", "rule": "dangerous-call", "file": str(path), "line": node.lineno, "message": name})
            if name in {"system", "popen"} and isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == "os":
                findings.append({"severity": "error", "rule": "os-command-shell", "file": str(path), "line": node.lineno})
            if name in {"run", "Popen", "call", "check_call", "check_output"} and isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == "subprocess":
                for kw in node.keywords:
                    if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                        findings.append({"severity": "error", "rule": "subprocess-shell-true", "file": str(path), "line": node.lineno})
    return findings

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("skill_dir", type=Path, help="repository or project root to inspect")
    ap.add_argument("report", type=Path)
    ap.add_argument("--scan-path", action="append", help="file or directory relative to skill_dir; repeatable; default: scripts")
    ap.add_argument("--allow-symlinks", action="store_true", help="do not fail on symlink files; use only with a documented reason")
    ap.add_argument("--allow-world-writable", action="store_true", help="do not fail on world-writable files; use only with a documented reason")
    args = ap.parse_args()
    root = args.skill_dir.resolve()
    if not root.is_dir():
        print(f"skill directory does not exist: {root}", file=sys.stderr)
        return 2
    requested = args.scan_path or ["scripts"]
    scripts = []
    for raw in requested:
        candidate = (root / raw).resolve() if not Path(raw).is_absolute() else Path(raw).resolve()
        try:
            candidate.relative_to(root)
        except ValueError:
            print(f"scan path escapes the repository root: {candidate}", file=sys.stderr)
            return 2
        if candidate.is_file() and candidate.suffix == ".py":
            scripts.append(candidate)
        elif candidate.is_dir():
            scripts.extend(candidate.rglob("*.py"))
        else:
            print(f"scan path does not exist or is not a Python file/directory: {candidate}", file=sys.stderr)
            return 2
    scripts = sorted({path for path in scripts if path.is_file()})
    findings = []
    compile_results = []
    for path in scripts:
        try:
            subprocess.run([sys.executable, "-m", "py_compile", str(path)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            compile_results.append({"file": str(path), "ok": True})
        except subprocess.CalledProcessError as exc:
            compile_results.append({"file": str(path), "ok": False, "stderr": exc.stderr[-1000:]})
        findings.extend(source_findings(path))
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.is_symlink() and not args.allow_symlinks:
            findings.append({"severity": "error", "rule": "symlink-file", "file": str(path)})
        if path.is_file() and path.stat().st_mode & stat.S_IWOTH and not args.allow_world_writable:
            findings.append({"severity": "error", "rule": "world-writable-file", "file": str(path)})
    result = {
        "ok": not findings and all(row["ok"] for row in compile_results),
        "scripts_checked": len(scripts),
        "compile": compile_results,
        "findings": findings,
        "rules": ["py_compile", "AST dangerous calls/imports", "subprocess shell=True", "secret patterns", "symlinks", "world-writable files"],
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1

if __name__ == "__main__":
    raise SystemExit(main())

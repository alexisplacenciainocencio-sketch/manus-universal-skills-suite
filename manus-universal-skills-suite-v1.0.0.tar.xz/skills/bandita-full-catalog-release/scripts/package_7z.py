#!/usr/bin/env python3
"""Create and verify a solid LZMA2 7z archive."""
from pathlib import Path
import argparse, hashlib, json, shutil, subprocess, tempfile

def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def excluded(path):
    return (path.name.startswith("manifest_") and path.suffix == ".sha256") or (path.name.startswith("validation_") and path.suffix == ".json")

def inventory(root):
    return {p.relative_to(root).as_posix(): sha(p) for p in sorted(root.rglob("*")) if p.is_file() and not excluded(p)}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("root", type=Path)
    ap.add_argument("archive", type=Path)
    ap.add_argument("--report", type=Path)
    args = ap.parse_args()
    expected = inventory(args.root)
    args.archive.unlink(missing_ok=True)
    subprocess.run([
        "7z", "a", "-t7z", "-mx=9", "-m0=lzma2", "-md=64m", "-mmt=on", "-ms=on",
        str(args.archive), args.root.name,
    ], cwd=args.root.parent, check=True)
    test = subprocess.run(["7z", "t", str(args.archive)], capture_output=True, text=True)
    with tempfile.TemporaryDirectory(prefix="bandita_7z_") as temp:
        subprocess.run(["7z", "x", "-y", str(args.archive), f"-o{temp}"], check=True, stdout=subprocess.DEVNULL)
        actual = inventory(Path(temp) / args.root.name)
    result = {
        "archive": str(args.archive),
        "archive_sha256": sha(args.archive),
        "7z_test_ok": test.returncode == 0,
        "manifest_entries_checked": len(expected),
        "extraction_exact": expected == actual,
        "missing": sorted(set(expected) - set(actual)),
        "extra": sorted(set(actual) - set(expected)),
        "hash_mismatches": sorted(k for k in expected.keys() & actual.keys() if expected[k] != actual[k]),
    }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result["7z_test_ok"] and result["extraction_exact"] else 1)

if __name__ == "__main__":
    main()

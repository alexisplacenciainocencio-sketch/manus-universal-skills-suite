#!/usr/bin/env python3
"""Build regional full trees from an immutable base plus localized overlays."""
from pathlib import Path
import argparse, json, shutil

def build(base: Path, overlay: Path, out: Path, language: str, cutoff: str) -> None:
    if out.exists():
        shutil.rmtree(out)
    shutil.copytree(base, out)
    shutil.copytree(overlay, out, dirs_exist_ok=True)
    (out / "FULL_CHAT_CONTENT_SCOPE.json").write_text(
        json.dumps({
            "language": language,
            "source_base": str(base),
            "overlay": str(overlay),
            "full_tree_preserved": True,
            "source_cutoff": cutoff,
        }, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("base", type=Path)
    ap.add_argument("overlay_do", type=Path)
    ap.add_argument("overlay_us", type=Path)
    ap.add_argument("out_prefix", type=Path)
    ap.add_argument("--cutoff", default="YYYY-MM-DD")
    args = ap.parse_args()
    build(args.base, args.overlay_do, Path(f"{args.out_prefix}_do"), "es-DO", args.cutoff)
    build(args.base, args.overlay_us, Path(f"{args.out_prefix}_us"), "en-US", args.cutoff)
    print("built", Path(f"{args.out_prefix}_do"), Path(f"{args.out_prefix}_us"))

if __name__ == "__main__":
    main()

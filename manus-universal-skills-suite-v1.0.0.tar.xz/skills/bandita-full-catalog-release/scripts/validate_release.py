#!/usr/bin/env python3
"""Validate two regional trees before packaging."""
from pathlib import Path
import argparse, hashlib, json, re

TEXT = {".md", ".txt", ".json", ".csv", ".tsv", ".yaml", ".yml", ".py", ".sh", ".js", ".ts", ".html", ".xml"}
SECRET_MARKERS = ("ghp_", "github_pat_", "xoxb-", "-----begin private key-----", "openai_api_key=")

def paths(root):
    return sorted(p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file())

def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def url_set(root, scope):
    found = set()
    target = root / scope
    if not target.exists():
        return found
    for path in target.rglob("*"):
        if path.is_file() and path.suffix.lower() in TEXT:
            text = path.read_text(encoding="utf-8", errors="ignore")
            found.update(x.rstrip(".,;") for x in re.findall(r"https?://[^\s)<>\"']+", text))
    return found

def inspect(root, historical_prefix, current_scope):
    ps = paths(root)
    binaries = {p: sha(root / p) for p in ps if Path(p).suffix.lower() not in TEXT and not p.endswith(".sha256")}
    secrets = []
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() in TEXT:
            text = p.read_text(encoding="utf-8", errors="ignore").lower()
            if any(marker in text for marker in SECRET_MARKERS):
                secrets.append(p.relative_to(root).as_posix())
    return {
        "files": len(ps),
        "bytes": sum((root / p).stat().st_size for p in ps),
        "historical_files": sum(p.startswith(historical_prefix) for p in ps),
        "current_urls": len(url_set(root, current_scope)),
        "binary_hashes": binaries,
        "secret_hits": secrets,
    }

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("do", type=Path)
    ap.add_argument("us", type=Path)
    ap.add_argument("report", type=Path)
    ap.add_argument("--historical-prefix", default="08_materiales_historicos_y_entrada/")
    ap.add_argument("--current-scope", default="08_actualizacion_extrema_2026-08-23")
    ap.add_argument("--expected-historical", type=int)
    args = ap.parse_args()
    do, us = inspect(args.do, args.historical_prefix, args.current_scope), inspect(args.us, args.historical_prefix, args.current_scope)
    result = {
        "do": do,
        "us": us,
        "same_paths": paths(args.do) == paths(args.us),
        "same_current_urls": url_set(args.do, args.current_scope) == url_set(args.us, args.current_scope),
        "same_binary_hashes": do["binary_hashes"] == us["binary_hashes"],
    }
    result["ok"] = result["same_paths"] and result["same_current_urls"] and result["same_binary_hashes"] and not do["secret_hits"] and not us["secret_hits"]
    if args.expected_historical is not None:
        result["expected_historical_ok"] = do["historical_files"] == args.expected_historical and us["historical_files"] == args.expected_historical
        result["ok"] = result["ok"] and result["expected_historical_ok"]
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result["ok"] else 1)

if __name__ == "__main__":
    main()

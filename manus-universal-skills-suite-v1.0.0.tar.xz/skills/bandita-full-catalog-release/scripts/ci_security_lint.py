#!/usr/bin/env python3
"""Run the Bandita security linter in CI/CD without shell execution or network access."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path


def load_config(path: Path | None) -> dict:
    if path is None:
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("CI lint configuration must be a JSON object")
    return data


def as_bool(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo-root", default=None, help="repository root; default: BANDITA_REPO_ROOT or .")
    ap.add_argument("--linter", default=None, help="linter path; default: BANDITA_LINTER or sibling lint_security.py")
    ap.add_argument("--config", type=Path, help="optional JSON configuration")
    ap.add_argument("--scan-path", action="append", help="Python file/directory relative to repo root; repeatable")
    ap.add_argument("--report", default=None, help="JSON report path; default: BANDITA_REPORT or .bandita-artifacts/security-lint.json")
    ap.add_argument("--allow-symlinks", action="store_true")
    ap.add_argument("--allow-world-writable", action="store_true")
    ap.add_argument("--quiet", action="store_true", help="suppress linter stdout/stderr; report remains available")
    args = ap.parse_args()

    config = load_config(args.config)
    repo_value = args.repo_root or config.get("repo_root") or os.environ.get("BANDITA_REPO_ROOT") or "."
    root = Path(repo_value).expanduser().resolve()
    if not root.is_dir():
        print(f"repository root does not exist: {root}", file=sys.stderr)
        return 2

    default_linter = Path(__file__).with_name("lint_security.py")
    linter_value = args.linter or config.get("linter") or os.environ.get("BANDITA_LINTER") or str(default_linter)
    linter = Path(linter_value).expanduser()
    if not linter.is_absolute():
        linter = (root / linter).resolve()
    else:
        linter = linter.resolve()
    if not linter.is_file() or linter.suffix != ".py":
        print(f"linter does not exist or is not a Python file: {linter}", file=sys.stderr)
        return 2

    report_value = args.report or config.get("report") or os.environ.get("BANDITA_REPORT") or ".bandita-artifacts/security-lint.json"
    report = Path(report_value).expanduser()
    if not report.is_absolute():
        report = (root / report).resolve()
    else:
        report = report.resolve()
    report.parent.mkdir(parents=True, exist_ok=True)

    configured_paths = config.get("scan_paths") or []
    env_paths = [p for p in os.environ.get("BANDITA_SCAN_PATHS", "").split(os.pathsep) if p]
    scan_paths = args.scan_path or configured_paths or env_paths or ["scripts"]
    if not isinstance(scan_paths, list) or not all(isinstance(p, str) and p for p in scan_paths):
        print("scan_paths must be a non-empty list of strings", file=sys.stderr)
        return 2

    command = [sys.executable, str(linter), str(root), str(report)]
    for scan_path in scan_paths:
        command.extend(["--scan-path", scan_path])
    if args.allow_symlinks or as_bool(config.get("allow_symlinks")):
        command.append("--allow-symlinks")
    if args.allow_world_writable or as_bool(config.get("allow_world_writable")):
        command.append("--allow-world-writable")

    completed = subprocess.run(command, cwd=root, capture_output=True, text=True, check=False)
    if not args.quiet:
        if completed.stdout:
            print(completed.stdout, end="")
        if completed.stderr:
            print(completed.stderr, end="", file=sys.stderr)

    wrapper = {
        "ok": completed.returncode == 0,
        "runner": "ci_security_lint.py",
        "repo_root": str(root),
        "linter": str(linter),
        "report": str(report),
        "scan_paths": scan_paths,
        "returncode": completed.returncode,
        "network_used": False,
        "shell_used": False,
    }
    wrapper_path = report.with_name(report.stem + ".runner.json")
    wrapper_path.write_text(json.dumps(wrapper, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return completed.returncode


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Write a deterministic relative-path SHA-256 manifest."""
from pathlib import Path
import argparse, hashlib

def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def excluded(path: Path) -> bool:
    return (path.name.startswith("manifest_") and path.suffix == ".sha256") or (path.name.startswith("validation_") and path.suffix == ".json")

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("root", type=Path)
    ap.add_argument("output", type=Path)
    args = ap.parse_args()
    rows = []
    for path in sorted(args.root.rglob("*")):
        if path.is_file() and not excluded(path):
            rows.append(f"{digest(path)}  {path.relative_to(args.root).as_posix()}\n")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("".join(rows), encoding="utf-8")
    print(f"entries={len(rows)} output={args.output}")

if __name__ == "__main__":
    main()

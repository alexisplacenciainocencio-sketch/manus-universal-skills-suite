# {{TÍTULO DEL RELEASE}}

**Edición:** {{versión}}  · **Variante:** {{do o us}}  · **Corte:** {{AAAA-MM-DD}}

## Alcance

{{Qué se preservó, qué capa vigente se añadió y qué fuentes o overlays se usaron.}}

| Medida | Valor |
|---|---:|
| Archivos del árbol | {{n}} |
| Entradas del manifest | {{n}} |
| Archivos históricos/entrada | {{n}} |
| Bytes sin comprimir | {{n}} |
| Tamaño del contenedor | {{n}} |

## Equivalencia regional

{{Confirmar rutas comunes, categorías, estados, URLs técnicas y diferencias lingüísticas permitidas.}}

## Integridad

- **Contenedor:** `{{archivo}}`
- **SHA-256 exterior:** `{{hash}}`
- **Prueba:** `7z t` o `unzip -tq` → {{resultado}}
- **Extracción:** {{exacta/no exacta}}
- **Faltantes, extras, discrepancias:** {{resultado}}

## Actualizaciones y pendientes

{{Cambios de evidencia, conflictos, recursos no localizados y revisión humana pendiente.}}

## Límite lingüístico e histórico

{{Indicar qué se tradujo en la capa vigente y si el material histórico se conserva literalmente.}}

## {{NOMBRE}}

**Naturaleza:** {{aplicación | cliente | extensión | fuente | parser | plugin | catálogo | proveedor | servidor | módulo | herramienta}}

**Qué hace:** {{función respaldada por la fuente primaria; si falta evidencia, declararlo}}

**Para quién y cómo encaja:** {{audiencia, ecosistema, relación con cliente/fuente/servidor y diferencias frente a alternativas}}

**Preparación:** {{plataforma, Android/API, arquitectura, permisos, dependencias, instalación y rollback documentados}}

**Evolución observada:** {{release/tag/commit, rama, fecha de revisión, archivado, fork, migración o ausencia de actividad}}

**Estado y certeza:** {{estado calibrado}} · **Licencia:** {{licencia o licencia no confirmada}}

**Enlaces separados:**

- **Desarrollador/mantenedor:** {{URL o No localizado}}
- **Canal de actualización:** {{URL o No localizado}}
- **Repositorio/fuente primaria:** {{URL}}
- **Distribución directa:** {{URL exacta o No se encontró enlace directo verificable}}

**Comprobación:** {{HTTP, redirección, JSON, asset, rama, fecha y resultado}}

**Lo que sí está respaldado:** {{afirmaciones con fuente}}

**Lo que no debe asumirse:** {{seguridad, autorización, continuidad, compatibilidad o disponibilidad no demostradas}}

**Cómo elegirlo:** {{criterio práctico y relación con otros recursos}}

**Fuentes:** {{enlaces y fecha de revisión}}

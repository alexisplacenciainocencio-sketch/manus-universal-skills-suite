---
name: bandita-full-catalog-release
description: Construir, localizar, auditar y entregar catálogos comunitarios integrales en paquetes reproducibles ZIP o 7z sin perder históricos, materiales de entrada ni controles. Usar cuando haya que fusionar una base heredada con una capa vigente, producir variantes regionales equivalentes, verificar repositorios/extensiones y demostrar integridad mediante manifests y extracción.
---

# Bandita Full Catalog Release

## Objetivo

Ejecutar un release integral y reversible de un catálogo comunitario amplio. Preservar el corpus heredado, superponer una capa vigente localizada, mantener inventarios equivalentes entre variantes y entregar un paquete verificable. No sustituir evidencia por popularidad, una URL accesible por continuidad ni un tag por una release estable.

## Flujo obligatorio

1. **Congelar el alcance.** Registrar edición, versión, fecha de corte, idiomas regionales, formatos de salida, fuente base, overlays, categorías, conteos esperados, cambios previstos y límites. No trabajar sobre el ZIP/7z recibido ni sobre la única copia de la edición anterior.

2. **Crear copias de trabajo.** Extraer cada fuente en una carpeta aislada. Probar archivos recibidos (`unzip -tq` o `7z t`), calcular SHA-256 e inventariar rutas y tamaños. No ejecutar scripts, APKs, binarios ni artefactos encontrados dentro de materiales no confiables.

3. **Construir árboles integrales.** Copiar la base histórica completa a un árbol por variante y superponer sólo la capa vigente correspondiente. Nunca borrar históricos, entradas, publicaciones antiguas, catálogos, ramas, perfiles, auditorías, scripts o controles para reducir tamaño. Registrar la procedencia de la base y del overlay.

4. **Localizar por capas.** Traducir y adaptar la publicación vigente a la variante solicitada. Conservar sin traducir nombres de repositorio, ramas, versiones, asset names, URL, hashes, identificadores y datos de control. Si el material histórico se conserva literalmente, declararlo: es material de entrada/procedencia, no recomendación vigente.

5. **Inventariar y clasificar.** Leer Markdown, TXT, JSON, TSV/CSV, manifests, auditorías y nombres de archivos. Separar aplicación/cliente, extensión, fuente, parser, plugin, catálogo, proveedor, servidor, módulo, índice y canal. Para Android separar AI, personalización, productividad, root, Magisk, KernelSU, APatch, Shizuku, ADB, sistema, privacidad, red, energía, diagnóstico y desarrollo.

6. **Deduplicar sin destruir identidad.** Normalizar URLs sólo para comparar. Deduplicar por URL canónica e identidad demostrada; mantener forks, mirrors, rebrands, clientes, servidores y extensiones separados salvo evidencia de identidad común. Conservar aliases, relaciones y rutas descartadas en la auditoría.

7. **Enriquecer fichas.** Para cada recurso completar, cuando exista evidencia: identidad, naturaleza, función, encaje, plataforma, requisitos, permisos, instalación, rollback, versión/señal, rama, licencia, evolución, límites y certeza. Usar `templates/catalog-entry.md`. Escribir ausencia explícita de evidencia en lugar de inventar una función o versión.

8. **Verificar cuatro enlaces separados.** Mantener `developer_maintainer`, `update_channel`, `repository_or_primary_source` y `direct_distribution`. Para índices de extensiones comprobar primero la rama y el nombre real del archivo en la fuente primaria. Distinguir ecosistemas y no mezclar Manga, Cursed Manga y Anime por compartir organización.

9. **Calibrar evidencia.** Preferir repositorio/README/release, perfil del mantenedor, API o metadatos estructurados, wiki/directorio y, por último, publicaciones comunitarias. Usar estados `Confirmado`, `Declarado por el proyecto`, `Verificado por metadatos`, `Descubrimiento comunitario`, `Necesita revisión`, `Archivado o legado` y `No localizado`. Separar disponibilidad observada, seguridad, compatibilidad, autorización y continuidad.

10. **Resolver conflictos recientes.** Registrar el corte exacto y la fecha de cada fuente. Si una captura o publicación contradice el README o repositorio primario, conservar ambas señales y marcar conflicto o confirmación pendiente. No convertir una captura en prueba única ni afirmar archivado por inferencia.

11. **Generar ramas editoriales.** Crear una edición maestra y ramas funcionales legibles. Una ficha puede repetirse para facilitar lectura, pero el catálogo estructurado conserva una única identidad. Separar extensiones, plugins, parsers, servidores, fuentes y clientes por función real.

12. **Aplicar estilo y accesibilidad.** Mantener Markdown UTF-8 y TXT seleccionable, párrafos respirables, separadores, contexto, FAQ y emojis semánticos moderados. No reducir la letra ni usar imagen/PDF escaneado como única forma de lectura.

13. **Aplicar seguridad y rollback.** No incluir credenciales, cookies, tokens, claves privadas, sesiones ni bibliotecas privadas. No evadir DRM, CAPTCHA, paywalls o controles. No recomendar APKs desconocidas. Para root, Magisk, KernelSU, APatch, Shizuku, ADB y automatización exigir copia de seguridad, permisos mínimos, supervisión y reversión documentada.

14. **Lintar y validar antes de empaquetar.** Ejecutar `scripts/lint_security.py` sobre la carpeta de la habilidad para compilar todos los scripts, analizar AST, detectar llamadas peligrosas, `subprocess` con `shell=True`, patrones de secretos, symlinks y archivos escribibles por cualquiera. Después comprobar igualdad de rutas entre variantes, presencia del histórico, conteos de registros/fichas/ramas, equivalencia de URLs técnicas, pares regionales, ausencia de secretos y existencia de documentos vigentes. Guardar un JSON con `ok` y cada criterio individual. Leer `references/security-linting.md` para interpretar advertencias.

15. **Generar manifests.** Usar SHA-256 relativo a cada archivo, excluyendo el manifest que se genera y todos los `validation_*.json` derivados, incluso en subdirectorios. Mantener esos archivos dentro del paquete; la exclusión sólo evita autorreferencia.

16. **Empaquetar y probar.** Para 7z usar `7z a -t7z -mx=9 -m0=lzma2 -md=64m -mmt=on -ms=on`. Ejecutar `7z t`, extraer a una carpeta temporal y comparar rutas y SHA-256 de todos los miembros cubiertos por el manifest. Calcular también el SHA-256 exterior del contenedor. Para ZIP usar nombres UTF-8 y `unzip -tq`.

17. **Entregar con límites claros.** Adjuntar primero contenedores, después resumen, manifests y validaciones. Declarar conteo, tamaño, hash, prueba, fecha de corte, exclusiones del manifest, pendientes y cualquier límite de traducción. No afirmar publicación real en GitHub si sólo se construyó localmente.

## Decisiones condicionales

- **“Todo el contenido”:** conservar la base completa, incluidos históricos y entradas; no entregar sólo el overlay vigente.
- **Dos idiomas:** crear árboles con las mismas rutas y esquema; localizar la capa vigente y conservar invariantes técnicos. Declarar si los históricos no se traducen.
- **Última hora:** fijar un nuevo corte, reauditar identidades y registrar fuentes; no inflar novedades contando campos modificados.
- **Distribución ausente:** escribir `No se encontró enlace directo verificable`; no fabricar `index.min.json`, `index.json`, `repo`, `releases/latest` ni assets.
- **Conflicto de fuentes:** ponderar la fuente primaria, conservar el conflicto y usar estado pendiente cuando corresponda.
- **GitHub no disponible:** continuar con fuentes públicas sin credenciales, marcar lo no comprobado y no insistir con tokens.

## Recursos modulares

Leer sólo lo necesario:

- `references/release-invariants.md`: estructura, capas y criterios de equivalencia.
- `references/evidence-and-links.md`: estados de certeza y cuatro tipos de enlace.
- `references/security-and-rollback.md`: exclusiones sensibles y recuperación segura.
- `references/security-linting.md`: linting estático, AST, secretos, permisos y límites del escáner.
- `references/ci-cd-integration.md`: GitHub Actions, configuración JSON, variables de entorno y códigos de salida.
- `references/packaging-and-manifests.md`: manifests, 7z, ZIP, extracción y hashes.
- `references/editorial-localization.md`: publicación vigente regional e históricos preservados.
- `templates/catalog-entry.md`: ficha ampliada de recurso.
- `templates/release-summary.md`: resumen final del release.
- `templates/github-actions-bandita-security.yml`: workflow de GitHub Actions listo para adaptar.

## Scripts

Ejecutar sobre copias de trabajo y con rutas explícitas:

- `scripts/build_full_trees.py BASE OVERLAY_DO OVERLAY_US OUT_PREFIX`: construir árboles regionales sin eliminar históricos.
- `scripts/build_manifest.py ROOT OUTPUT`: crear SHA-256 excluyendo manifests y validaciones derivadas.
- `scripts/validate_release.py DO US REPORT`: comparar rutas, históricos, binarios, URLs, conteos y marcadores de secretos.
- `scripts/package_7z.py ROOT ARCHIVE`: crear 7z LZMA2, probarlo, extraerlo y validar hashes.
- `scripts/lint_security.py SKILL_DIR REPORT`: compilar y auditar estáticamente los scripts de la habilidad.
- `scripts/ci_security_lint.py`: ejecutar el linter dentro de CI/CD con rutas, configuración y reporte adaptables.

## Finalización

Considerar completa la tarea sólo si cada variante conserva el corpus integral, las rutas son idénticas, la capa vigente está localizada, los enlaces no inventan rutas, la evidencia está calibrada, no hay secretos, el manifest es reproducible, el contenedor pasa `7z t` o `unzip -tq`, la extracción es exacta y los límites lingüísticos, históricos y editoriales están documentados.

## Política de velocidad sin pérdida de calidad

Separar el trabajo frecuente del gate de publicación. Ejecutar `/home/ubuntu/fast_validate_release.py --mode fast` para preflight de rutas, equivalencia y digests cacheados; ejecutar `--mode verify` para añadir la validación estructural, de enlaces, evidencia y seguridad. Ninguno de esos modos produce 7z ni certifica la integridad final del contenedor.

Ejecutar `--mode release` únicamente al entregar. Ese modo ignora la caché de hashes, rehace todos los SHA-256 cubiertos, regenera manifests, crea los dos 7z sólidos, corre `7z t`, extrae en temporal y compara cada ruta y digest. Mantener la caché fuera del árbol y aceptar reutilización sólo cuando coincidan tamaño y `mtime_ns`; no confiar en ella durante el gate final.

Para la sincronización de GitHub, conservar ETags por repositorio y release, registrar 200/304, errores, rate limit y corte UTC, aplicar backoff sólo a fallos transitorios y no descargar assets ni ejecutar código. No recomprimir por cada cambio documental: `fast` y `verify` entregan reportes; sólo `release` recrea contenedores. Leer `references/performance-profiles.md` y usar `scripts/optimized_release_gate.py` para el gate de doble variante.

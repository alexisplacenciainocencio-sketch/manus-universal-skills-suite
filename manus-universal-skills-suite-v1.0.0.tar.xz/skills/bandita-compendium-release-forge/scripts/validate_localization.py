#!/usr/bin/env python3
"""Lightweight localization audit; flags common editorial leakage, not technical literals."""
import argparse, json, re
from pathlib import Path
WORDS={
'en-US':{'es':r'\b(qué|cómo|lectura|servidor|actualización|verificado|fuente|aplicación|el|la|los|las)\b','pt':r'\b(que|como|leitura|servidor|atualização|verificado|fonte|aplicativo|o|a|os|as)\b'},
'es-DO':{'en':r'\b(the|what|how|reading|server|verified|source|application|this|and)\b','pt':r'\b(leitura|servidor|atualização|fonte|aplicativo|isso|uma)\b'},
'pt-BR':{'en':r'\b(the|what|how|reading|server|verified|source|application|this|and)\b','es':r'\b(qué|cómo|lectura|servidor|actualización|verificado|fuente|aplicación|el|la|los|las)\b'} }
def clean(s):
 s=re.sub(r'https?://\S+',' ',s); s=re.sub(r'`[^`]*`',' ',s); s=re.sub(r'\[[^]]*\]\([^)]*\)',' ',s); s=re.sub(r'\b[A-Za-z0-9_./:+-]+/[A-Za-z0-9_./:+-]+\b',' ',s); return s
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--langs',required=True); ap.add_argument('--out',required=True); a=ap.parse_args(); root=Path(a.root); langs=a.langs.split(','); result={'root':str(root),'variants':{},'ok':True}
 for lang in langs:
  hits=[]
  for p in root.rglob('*'):
   if not p.is_file() or p.suffix.lower() not in {'.md','.txt','.json','.tsv'}: continue
   s=clean(p.read_text(encoding='utf-8',errors='replace'))
   for other,pat in WORDS.get(lang,{}).items():
    for m in re.finditer(pat,s,re.I): hits.append({'path':str(p.relative_to(root)),'foreign_language':other,'match':m.group(0)})
  result['variants'][lang]={'foreign_prose_hits':hits}
  # This is a review signal, not an automatic release blocker, because technical catalogues contain English literals.
 Path(a.out).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps({'variants':len(result['variants']),'review_signals':sum(len(x['foreign_prose_hits']) for x in result['variants'].values())}))
if __name__=='__main__': main()

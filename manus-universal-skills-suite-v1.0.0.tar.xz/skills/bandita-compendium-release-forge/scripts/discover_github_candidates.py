#!/usr/bin/env python3
"""Discover public GitHub candidates; metadata only, no cloning or downloads."""
import argparse, json, time
from pathlib import Path
import requests


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--queries', required=True, help='Text file, one GitHub search query per line')
    ap.add_argument('--out', required=True)
    ap.add_argument('--per-page', type=int, default=30)
    ap.add_argument('--delay', type=float, default=1.0)
    args=ap.parse_args()
    headers={'Accept':'application/vnd.github+json','User-Agent':'bandita-compendium-release-forge/1.0'}
    queries=[x.strip() for x in Path(args.queries).read_text(encoding='utf-8').splitlines() if x.strip() and not x.lstrip().startswith('#')]
    result={'queries':queries,'cutoff_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'candidates':[],'errors':[]}
    seen=set()
    for query in queries:
        try:
            r=requests.get('https://api.github.com/search/repositories',params={'q':query,'per_page':args.per_page},headers=headers,timeout=20)
            if r.status_code != 200:
                result['errors'].append({'query':query,'status':r.status_code,'body':r.text[:300]})
                continue
            for item in r.json().get('items',[]):
                url=item.get('html_url','')
                if url and url not in seen:
                    seen.add(url)
                    result['candidates'].append({'name':item.get('full_name'),'url':url,'description':item.get('description'),'default_branch':item.get('default_branch'),'license_spdx':(item.get('license') or {}).get('spdx_id'),'archived':item.get('archived'),'updated_at':item.get('updated_at'),'stargazers_count':item.get('stargazers_count'),'forks_count':item.get('forks_count'),'topics':item.get('topics',[])})
        except Exception as e:
            result['errors'].append({'query':query,'error':type(e).__name__})
        time.sleep(args.delay)
    Path(args.out).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'candidates':len(result['candidates']),'errors':len(result['errors'])}))
    return 0 if result['candidates'] or not result['errors'] else 2

if __name__=='__main__': raise SystemExit(main())

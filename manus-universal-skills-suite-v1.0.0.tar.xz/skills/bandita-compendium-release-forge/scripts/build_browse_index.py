#!/usr/bin/env python3
"""Build an intuitive browse front door from a canonical catalog."""
import argparse
import json
import os
import re
import unicodedata
from collections import defaultdict
from pathlib import Path

TEXT = {
    'en-US': {'title':'Bandita Open Sauce Catalog','intro':'Start here: choose a category, platform or status, then open one canonical resource card.','cutoff':'Cutoff','category':'Browse by category','platform':'Browse by platform','status':'Browse by status','type':'Type','version':'Version or signal','source':'Primary source','developer':'Developer','distribution':'Direct distribution','relations':'Relations','archive':'Technical archive','search':'Search','cards':'canonical resource cards','not':'Not verified','what':'What it is','fit':'Best fit','platforms':'Platforms and scope','state':'Status and evidence','channel':'Update channel','risk':'Permissions and risk','evidence':'Evidence','browse':'Browse','how':'How to use this catalog','technical':'Technical archive and provenance','new':'New and refreshed','none':'None recorded.','current':'Current release','category_names':{'reading':'Reading, comics and libraries','video':'Video, anime and multimedia','audio':'Audio and music','servers':'Servers, self-hosting and personal cloud','android':'Android tools, Root and Shizuku','privacy':'Privacy, productivity and automation','extensions':'Extensions, plugins, parsers and distribution','other':'Other references'}},
    'es-DO': {'title':'Catálogo Open Sauce de la Bandita','intro':'Empieza aquí: elige una categoría, plataforma o estado y abre una ficha canónica por recurso.','cutoff':'Corte','category':'Explorar por categoría','platform':'Explorar por plataforma','status':'Explorar por estado','type':'Tipo','version':'Versión o señal','source':'Fuente primaria','developer':'Desarrollador','distribution':'Distribución directa','relations':'Relaciones','archive':'Archivo técnico','search':'Búsqueda','cards':'fichas canónicas de recursos','not':'No verificado','what':'Qué es','fit':'Para quién sirve','platforms':'Plataformas y alcance','state':'Estado y evidencia','channel':'Canal de actualización','risk':'Permisos y riesgo','evidence':'Evidencia','browse':'Explorar','how':'Cómo usar este catálogo','technical':'Archivo técnico y procedencia','new':'Novedades y refrescos','none':'No hay registros.','current':'Release actual','category_names':{'reading':'Lectura, cómics y bibliotecas','video':'Video, anime y multimedia','audio':'Audio y música','servers':'Servidores, autoalojamiento y nube personal','android':'Herramientas Android, Root y Shizuku','privacy':'Privacidad, productividad y automatización','extensions':'Extensiones, plugins, parsers y distribución','other':'Otras referencias'}},
    'pt-BR': {'title':'Catálogo Open Sauce da Bandita','intro':'Comece aqui: escolha uma categoria, plataforma ou status e abra uma ficha canônica por recurso.','cutoff':'Corte','category':'Explorar por categoria','platform':'Explorar por plataforma','status':'Explorar por status','type':'Tipo','version':'Versão ou sinal','source':'Fonte primária','developer':'Desenvolvedor','distribution':'Distribuição direta','relations':'Relações','archive':'Arquivo técnico','search':'Busca','cards':'fichas canônicas de recursos','not':'Não verificado','what':'O que é','fit':'Para quem serve','platforms':'Plataformas e escopo','state':'Status e evidência','channel':'Canal de atualização','risk':'Permissões e risco','evidence':'Evidência','browse':'Explorar','how':'Como usar este catálogo','technical':'Arquivo técnico e procedência','new':'Novidades e atualizações','none':'Nenhum registro.','current':'Release atual','category_names':{'reading':'Leitura, quadrinhos e bibliotecas','video':'Vídeo, anime e multimídia','audio':'Áudio e música','servers':'Servidores, auto-hospedagem e nuvem pessoal','android':'Ferramentas Android, Root e Shizuku','privacy':'Privacidade, produtividade e automação','extensions':'Extensões, plugins, parsers e distribuição','other':'Outras referências'}}
}

def t(lang):
    return TEXT.get(lang, TEXT['en-US'])

def slug(value):
    value=unicodedata.normalize('NFKD', value or '').encode('ascii','ignore').decode().lower()
    return re.sub(r'[^a-z0-9]+','-',value).strip('-') or 'resource'

def category_group(record):
    value=' '.join(str(record.get(k,'')) for k in ('category','kind','name','url')).lower()
    if any(x in value for x in ('extension','plugin','parser','source repo','distribution','manga repo')): return 'extensions'
    if any(x in value for x in ('server','self-host','jellyfin','navidrome','subsonic','cloud')): return 'servers'
    if any(x in value for x in ('audio','music','sound','equalizer','scrobbl')): return 'audio'
    if any(x in value for x in ('video','anime','film','movie','media','tv','stream')): return 'video'
    if any(x in value for x in ('manga','comic','novel','reading','book','mihon','komikku','tachiyomi')): return 'reading'
    if any(x in value for x in ('android','root','shizuku','adb','system','file manager','launcher','personalization','device')): return 'android'
    if any(x in value for x in ('privacy','productivity','automation','terminal','agent','password')): return 'privacy'
    return 'other'

def kind_folder(kind):
    value=(kind or '').lower()
    if any(x in value for x in ('fork','continuation','rebrand')): return 'forks_and_continuations'
    if any(x in value for x in ('extension','source','parser')): return 'extensions_and_sources'
    if any(x in value for x in ('server','plugin','client')): return 'servers_and_plugins'
    if any(x in value for x in ('tool','system','manager','utility')): return 'tools_and_system'
    return 'applications'

def platforms(record):
    value=' '.join(str(record.get(k,'')) for k in ('category','kind','name','editorial')).lower()
    found=[]
    for token,label in [('android tv','Android TV'),('android','Android'),('linux','Linux'),('windows','Windows'),('macos','macOS'),('desktop','Desktop'),('server','Server'),('web','Web'),('jellyfin','Server')]:
        if token in value and label not in found: found.append(label)
    return found or ['Cross-platform']

def href(card_path, from_dir):
    return Path(os.path.relpath(card_path, from_dir)).as_posix()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--catalog',required=True)
    ap.add_argument('--root',required=True)
    ap.add_argument('--out',required=True)
    ap.add_argument('--language',default='en-US')
    ap.add_argument('--cutoff',default='Not specified')
    args=ap.parse_args()
    data=json.loads(Path(args.catalog).read_text(encoding='utf-8'))
    records=data.get('records',[])
    out=Path(args.out); labels=t(args.language)
    start=out/'00_START_HERE'; cats=out/'10_CATEGORIES'; cards=out/'20_RESOURCE_CARDS'; relations=out/'30_RELATIONS'; updates=out/'40_UPDATES'; technical=out/'90_TECHNICAL_ARCHIVE'; release=out/'99_RELEASE'
    for directory in (start,cats,cards,relations,updates,technical,release): directory.mkdir(parents=True,exist_ok=True)
    card_paths={}; used=set()
    for record in records:
        base=slug(record.get('name') or record.get('identity'))
        if base in used: base += '-' + slug(record.get('identity','').split('/')[-1])[:12]
        used.add(base)
        card_path=Path('20_RESOURCE_CARDS')/kind_folder(record.get('kind'))/(base+'.md')
        card_paths[record.get('identity')]=card_path
        target=out/card_path; target.parent.mkdir(parents=True,exist_ok=True)
        editorial=record.get('editorial') or {}; links=record.get('technical_links') or {}; rels=record.get('relations') or []
        relation_text=''.join(f'- `{item}`\n' for item in rels) if rels else f"- {labels['none']}\n"
        card=(f"# {record.get('name','Unnamed resource')}\n\n> `{record.get('kind','resource')}` · `{record.get('status','needs_recheck')}` · `{labels['category_names'].get(category_group(record),category_group(record))}`\n\n"
              f"## {labels['what']}\n{editorial.get('what','No editorial description was verified.')}\n\n"
              f"## {labels['fit']}\n{editorial.get('fit','Read the primary source to assess fit.')}\n\n"
              f"## {labels['platforms']}\n"+' · '.join(f'`{item}`' for item in platforms(record))+f"\n\n"
              f"## {labels['version']}\n`{record.get('version') or record.get('observed_release') or labels['not']}`\n\n"
              f"## {labels['state']}\n`{record.get('status','needs_recheck')}` · {editorial.get('cutoff',args.cutoff if args.cutoff!='Not specified' else data.get('cutoff','Not specified'))}\n\n"
              f"## {labels['source']}\n{record.get('url',labels['not'])}\n\n"
              f"## {labels['developer']}\n{links.get('developer_maintainer',labels['not'])}\n\n"
              f"## {labels['distribution']}\n{links.get('direct_distribution',labels['not'])}\n\n"
              f"## {labels['channel']}\n{links.get('update_channel',labels['not'])}\n\n"
              f"## {labels['relations']}\n{relation_text}\n"
              f"## {labels['risk']}\n{editorial.get('limits','Review permissions and risk in the primary source.')}\n\n"
              f"## {labels['evidence']}\n{editorial.get('evidence','Primary repository or official documentation')}\n")
        target.write_text(card,encoding='utf-8')
    grouped={key:defaultdict(list) for key in ('category','platform','status')}
    for record in records:
        card_path=card_paths[record.get('identity')]
        row=f"- [{record.get('name','Unnamed')}]({href(card_path,Path('00_START_HERE'))}) — `{record.get('kind','resource')}` · `{record.get('status','needs_recheck')}`"
        grouped['category'][category_group(record)].append(row)
        grouped['status'][record.get('status','needs_recheck')].append(row)
        for item in platforms(record): grouped['platform'][item].append(row)
    def write_index(path,title,groups,category_mode=False):
        lines=[f'# {title}\n']
        for key in sorted(groups):
            heading=labels['category_names'].get(key,key) if category_mode else key
            lines += [f'## {heading}\n','\n'.join(sorted(groups[key]))+'\n']
        path.write_text('\n'.join(lines),encoding='utf-8')
    write_index(start/'BROWSE_BY_CATEGORY.md',labels['category'],grouped['category'],True)
    write_index(start/'BROWSE_BY_PLATFORM.md',labels['platform'],grouped['platform'])
    write_index(start/'BROWSE_BY_STATUS.md',labels['status'],grouped['status'])
    rows=['identity\tname\tcategory\tkind\tstatus\tversion\tplatforms\tprimary_url\tcard']
    for record in sorted(records,key=lambda item:(item.get('name','').lower(),item.get('identity',''))):
        rows.append('\t'.join([record.get('identity',''),record.get('name','').replace('\t',' '),labels['category_names'].get(category_group(record),category_group(record)),record.get('kind',''),record.get('status','needs_recheck'),str(record.get('version',record.get('observed_release',''))),'|'.join(platforms(record)),record.get('url',''),href(card_paths[record.get('identity')],Path('00_START_HERE'))]))
    (start/'SEARCH_INDEX.tsv').write_text('\n'.join(rows)+'\n',encoding='utf-8')
    cutoff=args.cutoff if args.cutoff!='Not specified' else data.get('cutoff','Not specified')
    home=(f"# {labels['title']}\n\n{labels['intro']}\n\n**{labels['cutoff']}:** `{cutoff}` · **{labels['cards']}:** {len(records)}\n\n"
          f"## {labels['browse']}\n\n- [BROWSE_BY_CATEGORY.md](BROWSE_BY_CATEGORY.md)\n- [BROWSE_BY_PLATFORM.md](BROWSE_BY_PLATFORM.md)\n- [BROWSE_BY_STATUS.md](BROWSE_BY_STATUS.md)\n- [SEARCH_INDEX.tsv](SEARCH_INDEX.tsv)\n- [{labels['new']}](../40_UPDATES/NEW_AND_REFRESHED.md)\n- [{labels['relations']}](../30_RELATIONS/FORK_MAP.md)\n- [{labels['technical']}](../90_TECHNICAL_ARCHIVE/README_ARCHIVE.md)\n\n"
          f"## {labels['how']}\n\nOpen a card for role, platform, observed version, primary source, distribution route, relations, permissions and limits. A repository proves that a project exists; it does not certify every binary, extension, source or service connected to it.\n")
    (start/'README_START_HERE.md').write_text(home,encoding='utf-8'); (start/'CATALOG_HOME.md').write_text(home,encoding='utf-8')
    (start/'QUICK_FILTERS.md').write_text(f"# {labels['search']}\n\nUse `SEARCH_INDEX.tsv` to filter by category, platform, kind, status or version. Search for `Fork`, `Extension`, `Server`, `Shizuku`, `Root`, `Android TV`, `Archived` or `needs_recheck`.\n",encoding='utf-8')
    for key in grouped['category']:
        directory=cats/slug(key); directory.mkdir(parents=True,exist_ok=True); category_rows=[]
        for record in records:
            if category_group(record)!=key: continue
            category_rows.append(f"- [{record.get('name','Unnamed')}]({href(card_paths[record.get('identity')],Path('10_CATEGORIES')/slug(key))}) — `{record.get('kind','resource')}` · `{record.get('status','needs_recheck')}`")
        (directory/'README.md').write_text(f"# {labels['category_names'].get(key,key)}\n\n"+'\n'.join(sorted(category_rows))+'\n',encoding='utf-8')
    fork_lines=['# Fork and upstream map\n']
    for record in records:
        if record.get('relations') or record.get('fork_of') or record.get('upstream'):
            fork_lines.append(f"- [{record.get('name')}]({href(card_paths[record.get('identity')],Path('30_RELATIONS'))}) — fork_of: `{record.get('fork_of','')}` · upstream: `{record.get('upstream','')}`")
    (relations/'FORK_MAP.md').write_text('\n'.join(fork_lines)+'\n',encoding='utf-8'); (relations/'UPSTREAM_MAP.md').write_text('\n'.join(fork_lines)+'\n',encoding='utf-8')
    alias_lines=['# Rebrands and aliases\n']+[f"- [{record.get('name')}]({href(card_paths[record.get('identity')],Path('30_RELATIONS'))}) — {', '.join(record.get('aliases',[]))}" for record in records if record.get('aliases')]
    (relations/'REBRANDS_AND_ALIASES.md').write_text('\n'.join(alias_lines)+'\n',encoding='utf-8')
    active={'active','stable','preview','experimental'}; archived={'observed','archived','discontinued','needs_recheck','historical'}
    (updates/'NEW_AND_REFRESHED.md').write_text(f"# {labels['new']}\n\n"+'\n'.join(f"- [{record.get('name')}]({href(card_paths[record.get('identity')],Path('40_UPDATES'))}) — `{record.get('version',record.get('observed_release','needs_recheck'))}`" for record in records if record.get('status') in active)+'\n',encoding='utf-8')
    (updates/'LATEST_CUT.md').write_text(f"# {labels['cutoff']}\n\n`{cutoff}`\n\nThis is a time-bound research snapshot.\n",encoding='utf-8')
    (updates/'OBSERVED_AND_ARCHIVED.md').write_text('# Observed and archived\n\n'+'\n'.join(f"- [{record.get('name')}]({href(card_paths[record.get('identity')],Path('40_UPDATES'))}) — `{record.get('status')}`" for record in records if record.get('status') in archived)+'\n',encoding='utf-8')
    (technical/'README_ARCHIVE.md').write_text(f"# {labels['archive']}\n\nManifests, audits, provenance, previous release layers and byte-preserved historical materials live here. They are not the primary browse surface.\n",encoding='utf-8')
    (release/'RELEASE_NOTES.md').write_text(f"# {labels['current']}\n\n{labels['cutoff']}: `{cutoff}`\n\n{labels['cards'].capitalize()}: {len(records)}\n",encoding='utf-8')
    print(json.dumps({'records':len(records),'cards':len(card_paths),'category_groups':len(grouped['category']),'platform_groups':len(grouped['platform'])}))

if __name__=='__main__':
    main()

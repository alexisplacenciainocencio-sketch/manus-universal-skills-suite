#!/usr/bin/env python3
"""Validate one tar.xz release by extraction and manifest checks."""
import argparse, hashlib, json, subprocess, tempfile
from pathlib import Path

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
 return h.hexdigest()
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--archive',required=True); ap.add_argument('--root-name',required=True); ap.add_argument('--manifest',required=True); ap.add_argument('--out',required=True); ap.add_argument('--expected-records',type=int)
 a=ap.parse_args(); archive=Path(a.archive).resolve(); result={'archive':str(archive),'archive_sha256':sha(archive),'tar_test':False,'manifest_hashes_match':False,'json_errors':[],'record_count':None,'unique_urls':None,'duplicate_urls':[],'ok':False}
 try:
  listing=subprocess.run(['tar','-tJf',str(archive)],capture_output=True,text=True,check=True).stdout.splitlines(); result['tar_test']=True; result['tar_entries']=len(listing)
  with tempfile.TemporaryDirectory(prefix='bandita_release_validate_') as td:
   dest=Path(td); subprocess.run(['tar','-xJf',str(archive),'-C',str(dest)],check=True); root=dest/a.root_name; manifest=root/a.manifest; checks=[]
   for line in manifest.read_text(encoding='utf-8').splitlines():
    digest,rel=line.split('  ',1); target=root/rel; checks.append(target.is_file() and sha(target)==digest)
   result['manifest_entries']=len(checks); result['manifest_hashes_match']=bool(checks) and all(checks)
   for p in root.rglob('*.json'):
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: result['json_errors'].append({'path':str(p.relative_to(root)),'error':type(e).__name__})
   cats=list(root.glob('**/catalog_*.json'))
   if cats:
    cat=json.loads(cats[0].read_text(encoding='utf-8')); rs=cat.get('records',[]); urls=[r.get('url','').rstrip('/').lower().replace('http://','https://') for r in rs]; result['record_count']=cat.get('record_count',len(rs)); result['unique_urls']=len(set(urls)); result['duplicate_urls']=sorted({u for u in urls if urls.count(u)>1 and u})
   result['extracted_files']=sum(1 for p in root.rglob('*') if p.is_file()); result['extracted_directories']=sum(1 for p in root.rglob('*') if p.is_dir())
  result['ok']=result['tar_test'] and result['manifest_hashes_match'] and not result['json_errors'] and not result['duplicate_urls'] and (a.expected_records is None or result['record_count']==a.expected_records)
 except Exception as e: result['error']={'type':type(e).__name__,'message':str(e)}
 Path(a.out).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps({'ok':result['ok'],'sha256':result['archive_sha256']})); return 0 if result['ok'] else 2
if __name__=='__main__': raise SystemExit(main())

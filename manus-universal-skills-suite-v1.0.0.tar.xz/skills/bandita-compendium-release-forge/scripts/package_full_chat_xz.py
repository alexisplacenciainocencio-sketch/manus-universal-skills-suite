#!/usr/bin/env python3
"""Package a release tree as tar.xz and create a non-self-referential manifest."""
import argparse, hashlib, json, os, subprocess, tempfile
from pathlib import Path

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
 return h.hexdigest()
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--output',required=True); ap.add_argument('--release',required=True); ap.add_argument('--manifest')
 a=ap.parse_args(); root=Path(a.root).resolve(); out=Path(a.output).resolve(); manifest=Path(a.manifest).resolve() if a.manifest else root/f'manifest_{a.release}.sha256'; manifest.parent.mkdir(parents=True,exist_ok=True)
 entries=[]
 for p in sorted(root.rglob('*')):
  if not p.is_file(): continue
  rel=p.relative_to(root).as_posix()
  if p.name.startswith('manifest_') and p.suffix=='.sha256': continue
  if p.name.startswith('validation_') and p.suffix=='.json': continue
  entries.append((sha(p),rel))
 manifest.write_text(''.join(f'{d}  {r}\n' for d,r in entries),encoding='utf-8')
 subprocess.run(['tar','-cJf',str(out),'-C',str(root.parent),root.name],check=True)
 report={'release':a.release,'root':root.name,'archive':str(out),'archive_sha256':sha(out),'archive_size_bytes':out.stat().st_size,'manifest':str(manifest),'manifest_entries':len(entries),'excluded_derived_entries':sum(1 for p in root.rglob('*') if p.is_file() and ((p.name.startswith('manifest_') and p.suffix=='.sha256') or (p.name.startswith('validation_') and p.suffix=='.json')))}
 Path(str(out)+'.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps(report,ensure_ascii=False)); return 0
if __name__=='__main__': raise SystemExit(main())

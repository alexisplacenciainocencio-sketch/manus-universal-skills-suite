#!/usr/bin/env python3
"""Normalize catalog identity and merge exact duplicate identity/URL records."""
import argparse, copy, json, re
from pathlib import Path


def canon(url):
    return (url or '').strip().rstrip('/').lower().replace('http://','https://')

def ident(record):
    if record.get('identity'): return record['identity'].strip().lower()
    u=canon(record.get('url',''))
    return 'repo:'+u.split('github.com/',1)[1] if 'github.com/' in u else 'url:'+u

def merge(a,b):
    out=copy.deepcopy(a)
    aliases=list(dict.fromkeys((out.get('aliases') or [])+(b.get('aliases') or [])))
    if a.get('url') and b.get('url') and canon(a['url'])!=canon(b['url']): aliases.append(b['url'])
    if aliases: out['aliases']=aliases
    for k,v in b.items():
        if k in ('aliases','relations'): continue
        if (k not in out or out[k] in ('',None,[],{})) and v not in ('',None,[],{}): out[k]=v
    for k in ('relations',):
        out[k]=list(dict.fromkeys((out.get(k) or [])+(b.get(k) or [])))
    return out

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--input',required=True); ap.add_argument('--output',required=True); ap.add_argument('--report')
    args=ap.parse_args(); data=json.loads(Path(args.input).read_text(encoding='utf-8'))
    records=data.get('records',data if isinstance(data,list) else [])
    by={}; merged=[]; events=[]
    for r in records:
        key=(ident(r),canon(r.get('url','')))
        # Merge same identity or same canonical URL, but never merge two distinct URLs merely by owner/upstream.
        existing_key=next((k for k in by if k[0]==key[0] or (key[1] and k[1]==key[1])),None)
        if existing_key is None:
            by[key]=copy.deepcopy(r); merged.append(by[key])
        else:
            before=copy.deepcopy(by[existing_key]); by[existing_key]=merge(by[existing_key],r)
            events.append({'identity':ident(r),'canonical_url':canon(r.get('url','')),'reason':'same identity or canonical URL','kept_name':by[existing_key].get('name'),'merged_aliases':by[existing_key].get('aliases',[])})
    result=copy.deepcopy(data) if isinstance(data,dict) else {'records':[]}
    result['records']=merged; result['record_count']=len(merged); result['unique_urls']=len({canon(r.get('url','')) for r in merged if r.get('url')}); result['unique_identities']=len({ident(r) for r in merged})
    Path(args.output).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if args.report: Path(args.report).write_text(json.dumps({'before':len(records),'after':len(merged),'merges':events},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'before':len(records),'after':len(merged),'merges':len(events)}))

if __name__=='__main__': main()

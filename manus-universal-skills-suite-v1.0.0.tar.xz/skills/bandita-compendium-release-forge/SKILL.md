---
name: bandita-compendium-release-forge
description: "Crear y actualizar catálogos comunitarios open source fáciles de explorar, con una interfaz documental tipo GitHub/GitLab/Codeberg: portada, búsqueda, filtros, categorías, fichas únicas, relaciones entre forks, fuentes primarias, estados, localización, preservación histórica, auditoría y paquetes TAR.XZ. Usar para compendios Bandita, inventarios full_chat, mapas de apps/extensiones o releases multilingües."
---

# Forja de catálogos explorables

La salida principal no debe parecer un volcado de carpetas cronológicas. Debe funcionar como un catálogo navegable: una persona abre `00_START_HERE/`, entiende qué contiene el proyecto, elige una categoría, busca una ficha y llega a la fuente primaria sin atravesar capas internas de release.

## Arquitectura de salida obligatoria

Crear una **puerta de entrada humana** y mantener la preservación técnica aparte:

```text
release_root/
├── 00_START_HERE/
│   ├── README_START_HERE.md
│   ├── CATALOG_HOME.md
│   ├── QUICK_FILTERS.md
│   ├── BROWSE_BY_CATEGORY.md
│   ├── BROWSE_BY_PLATFORM.md
│   ├── BROWSE_BY_STATUS.md
│   ├── SEARCH_INDEX.tsv
│   └── CHANGELOG_CURRENT.md
├── 10_CATEGORIES/
│   ├── reading/
│   ├── video_anime/
│   ├── audio_music/
│   ├── servers_self_hosting/
│   ├── android_tools/
│   ├── privacy_productivity/
│   └── extensions_plugins_parsers/
├── 20_RESOURCE_CARDS/
│   ├── applications/
│   ├── forks_and_continuations/
│   ├── extensions_and_sources/
│   ├── servers_and_plugins/
│   └── tools_and_system/
├── 30_RELATIONS/
│   ├── FORK_MAP.md
│   ├── UPSTREAM_MAP.md
│   ├── EXTENSION_ECOSYSTEMS.md
│   └── REBRANDS_AND_ALIASES.md
├── 40_UPDATES/
│   ├── LATEST_CUT.md
│   ├── NEW_AND_REFRESHED.md
│   └── OBSERVED_AND_ARCHIVED.md
├── 90_TECHNICAL_ARCHIVE/
│   ├── manifests/
│   ├── audits/
│   ├── provenance/
│   ├── previous_release_layers/
│   └── historical_materials/
└── 99_RELEASE/
    ├── RELEASE_NOTES.md
    ├── LANGUAGE_SCOPE.md
    └── SHA256SUMS.txt
```

No colocar `00.000.17`, `00.000.18` o `00.000.19` como carpetas principales de navegación. Las versiones son metadatos de una ficha y se conservan en `90_TECHNICAL_ARCHIVE/previous_release_layers/`. Si el usuario exige un full_chat byte a byte, guardar la copia intacta allí y crear la puerta de entrada encima, sin alterar los archivos heredados.

## Experiencia de exploración

Implementar estas reglas antes de redactar contenido:

- La primera pantalla debe explicar qué es el catálogo, el corte, los idiomas, el significado de los estados y cómo empezar.
- Cada categoría debe enlazar a fichas individuales; no presentar una lista larga de nombres sin contexto.
- Cada ficha debe responder en este orden: **qué es**, **para quién sirve**, **plataformas**, **versión o señal**, **estado**, **fuente primaria**, **desarrollador**, **distribución**, **relaciones**, **permisos/riesgo**, **límites**.
- Añadir etiquetas legibles como `Android`, `Android TV`, `Desktop`, `Server`, `Local`, `Streaming`, `Shizuku`, `Root`, `Extension`, `Fork`, `Archived` y `Experimental`.
- Presentar una sola ficha canónica por identidad. Mostrar forks, upstreams, aliases y rebrandings dentro de “Relaciones”, no como duplicados silenciosos.
- Ofrecer índices por categoría, plataforma, estado y fecha de actualización. El usuario no debe depender del orden alfabético de carpetas técnicas.
- Mantener enlaces primarios visibles y separar `Repository`, `Developer`, `Release`, `Direct distribution` y `Community channel`.
- Marcar enlaces no confirmados como `needs_recheck`; nunca inventar una ruta `index.min.json`, un asset o una release.
- Reducir la densidad visual con títulos cortos, separadores, párrafos respirables y tablas pequeñas. No repetir la misma advertencia en cada línea si puede aparecer en la ficha y en la portada.

## Flujo reutilizable

1. **Definir alcance.** Registrar categorías, plataformas, idiomas, corte temporal, formato, conservación histórica y orden de entrega.
2. **Congelar fuente.** Calcular SHA-256, listar archivos, contar registros, distinguir directorios de archivos y crear copias de trabajo aisladas.
3. **Descubrir por bloques.** Investigar lectura/extensiones, vídeo/anime, audio, servidores, Android/Shizuku/Root, privacidad/productividad y forks emergentes en paralelo.
4. **Verificar fuentes primarias.** Leer README, licencia, ramas, releases, issues relevantes y páginas oficiales. Registrar funciones declaradas, no promesas propias.
5. **Normalizar y deduplicar.** Canonicalizar URLs; fusionar únicamente el mismo repositorio, URL o rebranding documentado. Conservar aliases, upstream, fork y relaciones.
6. **Crear el registro canónico.** Guardar identidad, nombre, tipo, categoría, plataformas, estado, versión, enlaces, permisos, función, límites, evidencia y corte.
7. **Generar fichas.** Crear una ficha Markdown por identidad en `20_RESOURCE_CARDS/`; usar enlaces relativos desde todos los índices.
8. **Generar navegación.** Ejecutar `build_browse_index.py` para crear portada, índices, TSV de búsqueda, vistas por categoría/plataforma/estado y mapas de relaciones.
9. **Localizar.** Crear árboles separados `en-US`, `pt-BR` y `es-DO`. Traducir sólo la prosa editorial; conservar URLs, nombres, ramas, hashes, comandos, package IDs, código y rutas técnicas.
10. **Separar capas.** Poner históricos, manifests, auditorías, fuentes crudas y capas anteriores bajo `90_TECHNICAL_ARCHIVE/`; enlazarlos desde “Procedencia”, nunca desde la navegación principal como si fueran apps.
11. **Auditar.** Ejecutar auditoría de JSON, duplicados, enlaces, secretos aparentes, fugas lingüísticas, rutas rotas, permisos y consistencia de conteos.
12. **Empaquetar y probar.** Crear manifest no autorreferente, TAR.XZ, extracción temporal, verificación de hashes y comprobación de equivalencia entre variantes.
13. **Entregar.** Presentar primero los tres archivos y después el informe; declarar corte, estados no confirmados, históricos no traducidos y cualquier gate pendiente.

## Ficha canónica

Usar una ficha como esta, con adaptación de idioma:

```markdown
# Nombre del recurso

> `Application` · `Android` · `Active` · Updated: YYYY-MM-DD

## What it is
Descripción factual breve basada en fuente primaria.

## Best fit
Qué necesidad cubre y qué no cubre.

## Platforms and scope
`Android 10+` · `Android TV` · `Server` · `Local` · `Streaming`.

## Version and status
`vX.Y.Z` or `active main`; explicar si es estable, beta, experimental, archivado o requiere revalidación.

## Primary links
- Repository: <URL>
- Developer: <URL>
- Release: <URL>
- Direct distribution: <URL or Not verified>
- Community channel: <URL or Not verified>

## Relations
- Fork of: <identity or None>
- Upstream: <identity or None>
- Aliases/rebrandings: <list>

## Permissions and risk
Describir Root, Shizuku, ADB, Accessibility, overlay, SSH, MCP, instalación o fuentes externas cuando correspondan.

## Limits
Compatibilidad, licencias, disponibilidad, legalidad del contenido, estado de mantenimiento y cualquier dato no confirmado.

## Evidence
Primary README, release or official documentation; cutoff exacto.
```

## Identidad, estados y enlaces

Usar `repo:<host>/<owner>/<repository>` como identidad de repositorio. Canonicalizar para comparar con `https`, host/owner/repository en minúsculas y slash final retirado; conservar la grafía original visible. Estados válidos: `active`, `stable`, `preview`, `experimental`, `observed`, `archived`, `discontinued`, `needs_recheck` y `historical`.

Separar siempre `repository_or_primary_source`, `developer_maintainer`, `release_page`, `direct_distribution` y `update_channel`. Un HTTP 200, un commit reciente, una estrella o una release no certifican seguridad, compatibilidad, autorización ni mantenimiento futuro.

## Seguridad y preservación

No descargar ni ejecutar APK, IPA, JAR, rootfs, módulos, modelos, contenedores, scripts remotos ni código de terceros. Se permiten lecturas pasivas, metadatos, comprobaciones HTTP y hashes. Advertir sobre Root, Shizuku, ADB, Accessibility, overlays, DevicePolicyManager, LSPosed/Xposed, SSH, MCP, agentes remotos, instalación silenciosa y fuentes de terceros. No guardar tokens ni claves privadas.

Cuando se solicite full_chat, preservar el histórico byte a byte. Puede contener español u otros idiomas dentro de la edición en-US o pt-BR; declararlo como procedencia, no como traducción vigente. No borrar capas heredadas para que la interfaz se vea más limpia: moverlas a `90_TECHNICAL_ARCHIVE/` y crear índices relativos.

## Scripts incluidos

```bash
python3 scripts/discover_github_candidates.py --queries queries.txt --out candidates.json
python3 scripts/normalize_catalog.py --input catalog.json --output catalog.normalized.json --report dedup.json
python3 scripts/build_browse_index.py --catalog catalog.normalized.json --root release_root --out release_root
python3 scripts/audit_catalog.py --catalog catalog.normalized.json --root release_root --out audit.json
python3 scripts/validate_localization.py --root release_root --langs en-US,pt-BR,es-DO --out language_audit.json
python3 scripts/package_full_chat_xz.py --root release_root --output release.tar.xz --release 00.000.00
python3 scripts/validate_release.py --archive release.tar.xz --root-name release_root --manifest manifest_00.000.00.sha256 --out validation.json
```

## Criterio de aprobación

Aprobar sólo si cada variante tiene una puerta `00_START_HERE`, fichas enlazadas, búsqueda TSV, índices por categoría/plataforma/estado, relaciones visibles, JSON válido, cero duplicados reales, manifests verificables y separación explícita de archivo técnico e histórico. Si falla la localización, la deduplicación o la integridad, entregar un diagnóstico y no llamar definitiva a la release.

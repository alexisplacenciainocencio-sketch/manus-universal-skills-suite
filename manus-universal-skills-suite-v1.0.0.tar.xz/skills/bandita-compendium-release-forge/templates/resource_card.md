# [Resource name]

> `[kind]` · `[status]` · `[category]` · `[platforms]`

## What it is
[Short factual description from the primary source.]

## Best fit
[Who should use it and what it does not replace.]

## Version and status
`[version or signal]` · `[cutoff]`

## Primary links

| Link | URL |
|---|---|
| Repository | `[URL]` |
| Developer | `[URL]` |
| Release | `[URL]` |
| Direct distribution | `[URL or not verified]` |
| Update channel | `[URL or not verified]` |

## Relations

[Upstream, fork, continuation, rebrand, extension ecosystem or none recorded.]

## Permissions and risk

[Root, Shizuku, ADB, Accessibility, overlay, DevicePolicyManager, SSH, MCP, installation or external-source considerations.]

## Limits

[Compatibility, maintenance, legal-content, account, distribution and evidence limits.]

## Evidence

[Primary README, release or official documentation and exact cutoff.]

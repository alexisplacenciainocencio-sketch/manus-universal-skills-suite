# [Catalog title]

[One paragraph explaining what this catalog contains and who should use it.]

> **Cutoff:** `[timestamp]` · **Canonical cards:** `[count]` · **Language:** `[locale]`

## Browse

- [By category](BROWSE_BY_CATEGORY.md)
- [By platform](BROWSE_BY_PLATFORM.md)
- [By status](BROWSE_BY_STATUS.md)
- [Search index](SEARCH_INDEX.tsv)
- [New and refreshed](../40_UPDATES/NEW_AND_REFRESHED.md)
- [Fork and upstream map](../30_RELATIONS/FORK_MAP.md)
- [Technical archive](../90_TECHNICAL_ARCHIVE/README_ARCHIVE.md)

## Reading a card

Open one canonical card to see the resource's role, platform, observed version, primary source, distribution route, relations, permissions and limits. A repository proves that a project exists; it does not certify every binary, extension, source or service connected to it.

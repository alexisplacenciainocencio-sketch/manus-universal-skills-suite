# Esquema, identidad y normalización

## Identidad canónica

Usar `repo:<host>/<owner>/<repository>` para repositorios. Normalizar host, owner y repository a minúsculas sólo en el campo `identity`; conservar el URL visible con la grafía técnica declarada por la fuente. Para una distribución sin repositorio, usar `dist:<host>/<path>` y registrar el repositorio primario en `technical_links.repository_or_primary_source`.

## Registro recomendado

Campos mínimos: `identity`, `name`, `kind`, `category`, `url`, `status`, `editorial`, `technical_links`. Campos opcionales: `aliases`, `relations`, `upstream`, `fork_of`, `package_names`, `platforms`, `permissions`, `version_code`, `observed_release`.

`kind` debe distinguir al menos: `application`, `fork`, `extension repository`, `extension index`, `plugin`, `parser`, `server`, `client`, `distribution`, `guide` e `historical`. Una ficha puede tener `relations` hacia otra identidad, pero no debe contar un asset como aplicación.

## Canonicalización de URLs

1. Reemplazar `http://` por `https://` sólo para comparación.
2. Retirar el slash final.
3. No retirar query strings, ramas, tags ni nombres de asset: pueden ser parte de la ruta funcional.
4. No cambiar `raw.githubusercontent.com` por `github.com` ni viceversa.
5. Comparar con lowercase para deduplicación; conservar la URL original en `url` y `direct_distribution`.

## Conteos

Guardar `record_count` después de la deduplicación. Calcular también `unique_urls`, `unique_identities`, `active_count`, `archived_count` y `historical_count`. Si una fusión reduce filas, documentar `before`, `after`, canonical URL, aliases y razón en el changelog.

## Manifest

Un manifest SHA-256 debe tener una línea por archivo cubierto:

```text
<64 hex chars>  relative/path/to/file
```

Excluir del propio manifest únicamente `manifest_*.sha256` y `validation_*.json`, porque esos archivos se derivan después o pueden contener el hash del contenedor. No usar rutas absolutas ni incluir el manifest dentro de sí mismo.

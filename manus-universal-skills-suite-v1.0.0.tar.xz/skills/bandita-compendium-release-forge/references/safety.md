# Seguridad y clasificación de riesgo

## Riesgos que requieren advertencia

| Señal | Clasificación | Tratamiento |
|---|---|---|
| Root, Magisk, KernelSU, APatch | Privilegio del sistema | No recomendar sin backup y reversión |
| Shizuku, ADB, Dhizuku | Shell privilegiado | Registrar requisito y alcance exacto |
| Accessibility, overlay, MediaProjection | Control/interfaz sensible | Explicar por qué se pide y qué puede observar |
| DevicePolicyManager, work profile | Administración del dispositivo | Separar funciones de perfil y advertir efectos OEM |
| LSPosed/Xposed | Inyección en procesos | Advertir scope mínimo; no incluir System Framework/System UI sin fuente explícita |
| Instalación silenciosa, AAB/APKS/XAPK | Alteración de paquetes | Exigir fuente primaria y checksum cuando exista |
| SSH, MCP, agente remoto | Ejecución remota | Exigir alcance explícito, autenticación y revisión de comandos |
| Script `curl | sh` o instalador remoto | Ejecución de código | Enlazar, pero recomendar inspección local previa |
| Índice de extensiones/fuentes | Código o contenido de terceros | No confundir índice con aplicación ni fuente con autorización |

## Prohibiciones

No descargar ni ejecutar artefactos de terceros para “probarlos”. No sortear DRM, CAPTCHA, paywalls, autenticación o controles de acceso. No recomendar exploits, bypasses de seguridad, rootkits o módulos sin procedencia. No copiar secretos, tokens, claves API, claves privadas ni credenciales en manifests, ejemplos o catálogos.

## Comprobaciones permitidas

Se permite leer README, licencia, documentación, issues y releases; consultar metadatos públicos; comprobar códigos HTTP de URLs declaradas; verificar hashes de archivos ya disponibles; ejecutar validadores propios y `tar -tJf`, `7z t` sobre contenedores. No instalar, importar o ejecutar APK, JAR, rootfs, scripts remotos, modelos o código externo.

## Redacción de riesgos

Usar formulaciones calibradas: “el README declara”, “se observó en la release”, “requiere revalidación”, “es experimental” o “no se pudo confirmar”. Evitar “seguro”, “oficial”, “compatible con todo”, “sin riesgo” o “funciona universalmente”.

---
name: bandita-integral-skills-suite
description: Suite integral para investigar, verificar, enriquecer, localizar, gobernar, asegurar, validar y publicar catálogos comunitarios Open Sauce completos en variantes regionales, incluyendo árboles históricos, fichas, extensiones, plugins, parsers, CI/CD, manifests SHA-256 y paquetes 7z reproducibles. Usar cuando una tarea requiera fusionar corpus heredados con novedades verificadas, producir español dominicano e inglés estadounidense, o entregar releases equivalentes y auditables.
---

# Suite integral de habilidades de la Bandita

Usar esta suite como orquestador de cinco mega-habilidades y ocho subhabilidades. No reducir una tarea de compendio integral a una reescritura de textos: preservar el corpus, investigar fuentes nuevas, separar evidencia de interpretación y demostrar la integridad del release.

## Flujo obligatorio

1. **Congelar la base:** inventariar archivos, rutas, tamaños, hashes, históricos, entradas recibidas, publicaciones, catálogos, ramas, perfiles, auditorías, scripts y controles. Crear una copia de trabajo; nunca destruir la fuente.
2. **Investigar de nuevo:** ejecutar `mega/mega-scan-evidence.md` y leer `references/evidence-and-links.md`. Abrir las fuentes primarias; una búsqueda sólo descubre candidatos. Registrar fecha de consulta, versión, rama, licencia, release, asset y estado archivado.
3. **Enriquecer sin duplicar:** ejecutar `mega/mega-catalog-enrichment.md`. Mantener una identidad canónica por recurso y una ficha detallada con función, encaje, evolución, requisitos, riesgos, permisos y rollback.
4. **Localizar:** ejecutar `mega/mega-regional-localization.md`. Construir `do` y `us` con idénticas rutas, identidades, URLs, versiones, estados y controles. Traducir la capa vigente; clasificar los históricos preservados como referencia si no se traducen.
5. **Asegurar:** ejecutar `mega/mega-governance-security-ci.md`. Aplicar mínimos privilegios, detectar secretos, linting AST, rutas inseguras, symlinks, permisos, artefactos no confiables y configuración de CI sin shell ni red innecesaria.
6. **Publicar reproduciblemente:** ejecutar `mega/mega-release-packaging.md`. Generar manifests sin autorreferencia, comprimir con 7z sólido LZMA2, ejecutar `7z t`, extraer en temporal y comparar SHA-256 de cada entrada cubierta.
7. **Entregar con transparencia:** incluir paquetes, manifests, auditorías, resumen bilingüe o resúmenes regionales, hashes exteriores y límites del corte. No afirmar que una señal es una certeza ni que el contenido histórico fue traducido si no lo fue.

## Selección de subhabilidades

Leer sólo las subhabilidades necesarias, pero respetar la secuencia: `subskills/source-discovery.md` → `subskills/evidence-ledger.md` → `subskills/link-route-verification.md` → `subskills/record-enrichment.md` → `subskills/regional-localization.md` → `subskills/equivalence-deduplication.md` → `subskills/security-lint-ci.md` → `subskills/package-validation.md`.

## Recursos operativos

Los scripts de `scripts/` son deterministas y deben ejecutarse con rutas absolutas, copias de trabajo y parámetros explícitos. Usar `references/` para reglas largas y `templates/` para fichas y resúmenes. No incorporar credenciales, cookies, tokens, keystores, APKs desconocidos ni artefactos no verificados.

## Decisiones críticas

**¿La novedad tiene fuente primaria y versión?** Si no, registrar como candidato pendiente, no como recomendación confirmada. **¿Las dos variantes difieren en rutas?** Detener el release y corregir nombres antes de empaquetar. **¿La fuente muestra una ruta técnica?** Copiarla literalmente; no inventar `index.min.json`, ramas ni assets. **¿El recurso requiere Root, Shizuku o acceso privilegiado?** Añadir copia de seguridad, mínimo privilegio, prueba reversible y rollback. **¿La licencia es contradictoria?** Marcar reconciliación pendiente y no redistribuir como si estuviera resuelta.

## Perfiles operativos de velocidad y calidad

Usar `fast` para actualizaciones frecuentes: conservar ETags, no descargar activos, hacer preflight de rutas/symlinks/permisos y reutilizar digests únicamente cuando coincidan tamaño y `mtime_ns`. Usar `verify` para añadir la validación estructural, de enlaces, evidencia, equivalencia regional y seguridad. Usar `release` para forzar rehash completo, generar manifests, comprimir ambas variantes con 7z sólido, ejecutar `7z t`, extraer y comparar SHA-256 por entrada. `fast` y `verify` no producen 7z y nunca equivalen a la certificación final.

Leer `references/performance-profiles.md` antes de elegir el perfil. Mantener la caché de digests fuera del árbol publicable. La sincronización registra contadores 200/304, errores y límite mínimo observado; reintenta sólo errores transitorios con backoff acotado. No activar schedules, hosting persistente ni publicar en GitHub sin autorización explícita.

## Scripts de rendimiento

- `scripts/optimized_release_gate.py`: gate reproducible de doble variante; hash paralelo determinista, igualdad de rutas, preflight, 7z, `7z t`, extracción exacta y SHA exterior.
- `/home/ubuntu/fast_validate_release.py`: selector externo de perfiles `fast`, `verify` y `release`, con caché segura de digests y reportes JSON.
- `/home/ubuntu/realtime_sync_bandita.py`: sincronización pública incremental con ETags, métricas de estados HTTP, backoff y escritura condicional.

# {{name}}

**Tipo:** {{kind}}  
**Categoría:** {{category}}  
**Estado:** {{status}}  
**Certeza:** {{certainty}}  
**Versión observada:** {{version}}  
**Corte:** {{cutoff}}

## Qué hace

{{description}}

## Evolución y encaje

{{function_detail}}

## Enlaces separados

- **Desarrollador/mantenedor:** {{developer_maintainer}}
- **Canal de actualización:** {{update_channel}}
- **Repositorio/fuente primaria:** {{repository_or_primary_source}}
- **Distribución directa:** {{direct_distribution}}

## Compatibilidad, permisos y rollback

{{setup_and_compatibility}}

## Límites y riesgos

{{limits}}

**Riesgo:** {{risk}}

**Recomendación condicionada:** {{recommendation}}

# Resumen de release · {{release}} · {{language}}

**Corte de evidencia:** {{cutoff}}

**Árboles:** {{tree_files}} archivos; {{historical_files}} históricos; {{records}} registros vigentes.

**Equivalencia:** {{same_paths}}; URLs técnicas {{same_urls}}; binarios {{same_binary_hashes}}.

**Integridad:** `7z t` {{seven_zip_test}}; extracción exacta {{extraction_exact}}; SHA-256 exterior: {{archive_sha256}}.

**Límites:** {{limits}}

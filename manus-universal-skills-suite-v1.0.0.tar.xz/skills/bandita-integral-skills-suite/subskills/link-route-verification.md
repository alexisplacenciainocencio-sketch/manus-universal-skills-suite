# Subhabilidad · Verificación de enlaces y rutas

Cada ficha debe separar: `developer_maintainer`, `update_channel`, `repository_or_primary_source` y `direct_distribution`. Copiar literalmente URLs declaradas en README o releases. No inferir `index.json`, `index.min.json`, `index.pb`, ramas o assets por analogía con otro proyecto.

Comprobar que enlaces técnicos pertenezcan al recurso correcto, registrar si una URL sólo fue observada o también respondió, y mantener un `direct_distribution_check` que diga si se descargó; por defecto, no descargar ni ejecutar APKs.

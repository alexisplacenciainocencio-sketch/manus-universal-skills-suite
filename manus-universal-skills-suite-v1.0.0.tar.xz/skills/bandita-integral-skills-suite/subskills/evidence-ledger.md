# Subhabilidad · Ledger de evidencia

Para cada afirmación escribir: afirmación, fuente, fecha de consulta, tipo de fuente, fuerza, señales a favor, señales en contra, estado y próxima revisión. Mantener separadas observación, declaración del mantenedor, inferencia editorial y recomendación condicionada.

Cuando exista conflicto, conservarlo. Una captura o post comunitario puede documentar una señal, pero no sustituye metadatos primarios. Usar lenguaje proporcional: “ruta visible”, “release observada”, “licencia pendiente”, “confirmación primaria pendiente”.

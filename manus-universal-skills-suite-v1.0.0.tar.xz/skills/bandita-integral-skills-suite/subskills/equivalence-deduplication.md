# Subhabilidad · Equivalencia y deduplicación

Generar listas ordenadas de rutas relativas y comparar igualdad. Comparar también identidades, URLs técnicas, ramas, conteos, binarios y archivos no textuales. Deduplicar sólo por identidad demostrada; no fusionar un fork con upstream, una extensión con un cliente ni una página de distribución con el repositorio.

Si se agregan controles regionales, usar nombres comunes de ruta y contenido localizado dentro del archivo. Detener el release ante cualquier `path_diff`, faltante, extra o hash binario divergente no explicado.

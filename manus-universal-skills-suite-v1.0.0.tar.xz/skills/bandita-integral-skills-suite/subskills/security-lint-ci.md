# Subhabilidad · Seguridad, linting y CI/CD

Ejecutar compilación y análisis AST sobre los scripts. Fallar ante secretos, claves privadas, `eval`, `exec`, shell injection, `shell=True`, symlinks fuera del repositorio, `..` en rutas o permisos world-writable, salvo excepciones explícitas y auditadas.

En CI aceptar configuración JSON, argumentos y variables de entorno con precedencia documentada. No usar red ni shell para invocar el linter; devolver `0` sin hallazgos, `1` con hallazgos y `2` ante configuración inválida. En GitHub Actions aplicar `contents: read`, fijar acciones por SHA cuando sea posible y no exponer secretos en logs.

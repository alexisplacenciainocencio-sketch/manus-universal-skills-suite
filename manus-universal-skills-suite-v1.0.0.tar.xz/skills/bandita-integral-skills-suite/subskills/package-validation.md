# Subhabilidad · Manifests, 7z y validación

Calcular SHA-256 de cada archivo incluido. Excluir del manifest el propio manifest y todos los `validation_*.json`, pero conservarlos en el árbol y archivo. Empaquetar con LZMA2 sólido, probar con `7z t`, extraer en temporal y comparar la misma función de inventario para detectar faltantes, extras y discrepancias.

Guardar el informe con archivos, bytes, entries del manifest, tamaño comprimido, SHA-256 exterior, salida de `7z t`, extracción exacta y límites. No entregar sólo un resumen verbal ni ocultar diferencias entre el árbol fuente y el contenedor.

# Subhabilidad · Enriquecimiento de fichas

Ampliar cada identidad con nombre, tipo, categoría, función, versión, evolución, licencia, requisitos, compatibilidad, riesgos, permisos, privacidad, backup, rollback, límites y recomendación. Escribir una descripción narrativa y después los campos estructurados; no rellenar huecos con suposiciones.

Si el proyecto está archivado, discontinuado, experimental o sin licencia clara, expresarlo en `status`, `certainty` y `limits`. Registrar la fuente de la versión y diferenciar release publicada de actividad de rama.

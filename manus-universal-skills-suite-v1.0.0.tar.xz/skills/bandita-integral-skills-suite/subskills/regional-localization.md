# Subhabilidad · Localización `do`/`us`

Construir dos salidas desde la misma base. Traducir la capa vigente y sus resúmenes; preservar históricos como fuente si la traducción completa no se hizo. Mantener sin traducir URLs, nombres de repositorio, ramas, versiones, hashes, nombres de asset, comandos y códigos.

Usar español dominicano claro y accesible en `do`, e inglés estadounidense profesional en `us`. Comparar rutas y conjuntos de URLs después de escribir ambas variantes.

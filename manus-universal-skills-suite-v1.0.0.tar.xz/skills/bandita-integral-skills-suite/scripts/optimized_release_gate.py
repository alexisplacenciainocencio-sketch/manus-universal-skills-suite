#!/usr/bin/env python3
"""Fast, deterministic release gate for two equivalent regional trees.

Default mode remains full: manifests, 7z test, extraction, and SHA-256 comparison.
Use --verify quick only for an interim check; it never replaces the final full gate.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, stat, subprocess, tempfile
from pathlib import Path
from typing import Iterable

TEXT_EXT={'.md','.txt','.json','.yaml','.yml','.toml','.ini','.cfg','.conf','.py','.sh','.js','.ts','.tsx','.jsx','.html','.xml','.csv','.tsv','.sha256','.log'}

def sha256(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def all_files(root:Path)->list[Path]:
    return sorted(p for p in root.rglob('*') if p.is_file())

def included(p:Path)->bool:
    n=p.name.lower()
    return not (n.startswith('manifest_') and p.suffix.lower()=='.sha256') and not (n.startswith('validation_') and p.suffix.lower()=='.json')

def inventory(root:Path, workers:int)->list[tuple[str,str]]:
    paths=[p for p in all_files(root) if included(p)]
    def one(p:Path): return (p.relative_to(root).as_posix(),sha256(p))
    if workers==1:
        out=[one(p) for p in paths]
    else:
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
            out=list(ex.map(one,paths))
    return sorted(out)

def preflight(root:Path)->dict:
    issues=[]
    if not root.is_dir(): return {'ok':False,'issues':['missing_root'],'files':0}
    fs=all_files(root)
    symlinks=[str(p.relative_to(root)) for p in fs if p.is_symlink()]
    writable=[str(p.relative_to(root)) for p in fs if p.stat().st_mode & stat.S_IWOTH]
    if symlinks: issues.append({'rule':'symlink','files':symlinks[:20],'count':len(symlinks)})
    if writable: issues.append({'rule':'world_writable','files':writable[:20],'count':len(writable)})
    return {'ok':not issues,'issues':issues,'files':len(fs),'bytes':sum(p.stat().st_size for p in fs),'historical':sum(p.relative_to(root).as_posix().startswith('08_materiales_historicos_y_entrada/') for p in fs)}

def write_manifest(root:Path, entries:list[tuple[str,str]], name:str)->Path:
    p=root/'06_control_y_auditoria'/name
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(''.join(f'{digest}  {relative}\n' for relative,digest in entries),encoding='utf-8')
    return p

def package_one(root:Path, archive:Path, entries:list[tuple[str,str]], verify:str, manifest_name:str)->dict:
    if archive.exists(): archive.unlink()
    subprocess.run(['7z','a','-t7z','-mx=9','-m0=lzma2','-md=64m','-mmt=on','-ms=on',str(archive),root.name],cwd=root.parent,check=True,stdout=subprocess.DEVNULL)
    test=subprocess.run(['7z','t',str(archive)],capture_output=True,text=True)
    result={'archive':str(archive),'archive_sha256':sha256(archive),'seven_zip_test_ok':test.returncode==0,'verify_mode':verify}
    if verify=='quick':
        result.update({'extraction_exact':None,'missing':[],'extra':[],'hash_mismatches':[]})
        return result
    with tempfile.TemporaryDirectory(prefix='bandita_fast_gate_') as tmp:
        subprocess.run(['7z','x','-y',str(archive),f'-o{tmp}'],check=True,stdout=subprocess.DEVNULL)
        extracted=Path(tmp)/root.name
        actual=dict(inventory(extracted,1)); expected=dict(entries)
        missing=sorted(set(expected)-set(actual)); extra=sorted(set(actual)-set(expected))
        mismatches=sorted(k for k in expected if k in actual and expected[k]!=actual[k])
    result.update({'extraction_exact':not(missing or extra or mismatches),'missing':missing,'extra':extra,'hash_mismatches':mismatches})
    return result

def main()->int:
    ap=argparse.ArgumentParser(description='Optimized but deterministic Bandita regional release gate')
    ap.add_argument('--do-root',required=True,type=Path); ap.add_argument('--us-root',required=True,type=Path)
    ap.add_argument('--output-dir',required=True,type=Path); ap.add_argument('--release',required=True)
    ap.add_argument('--verify',choices=('quick','full'),default='full')
    ap.add_argument('--hash-workers',type=int,default=min(8,os.cpu_count() or 1))
    ap.add_argument('--manifest-name',default='manifest_full_chat.sha256')
    ap.add_argument('--report-name',default='optimized_release_gate.json')
    args=ap.parse_args()
    if not 1<=args.hash_workers<=32: ap.error('--hash-workers must be between 1 and 32')
    roots={'do':args.do_root,'us':args.us_root}; pre={k:preflight(v) for k,v in roots.items()}
    if not all(x['ok'] for x in pre.values()):
        args.output_dir.mkdir(parents=True,exist_ok=True); (args.output_dir/args.report_name).write_text(json.dumps({'ok':False,'preflight':pre},indent=2)+'\n'); return 2
    paths={k:[p.relative_to(v).as_posix() for p in all_files(v)] for k,v in roots.items()}
    if paths['do']!=paths['us']:
        diff={'only_do':sorted(set(paths['do'])-set(paths['us'])),'only_us':sorted(set(paths['us'])-set(paths['do']))}
        args.output_dir.mkdir(parents=True,exist_ok=True); (args.output_dir/args.report_name).write_text(json.dumps({'ok':False,'preflight':pre,'path_diff':diff},indent=2)+'\n'); return 2
    entries={k:inventory(v,args.hash_workers) for k,v in roots.items()}
    if [x[0] for x in entries['do']] != [x[0] for x in entries['us']]: return 2
    reports={}
    for lang,root in roots.items():
        write_manifest(root,entries[lang],args.manifest_name)
        archive=args.output_dir/f'bandita_{args.release}_{lang}.7z'
        reports[lang]=package_one(root,archive,entries[lang],args.verify,args.manifest_name)
        reports[lang].update(pre[lang]); reports[lang]['manifest_entries']=len(entries[lang])
    report={'schema':'bandita-optimized-release-gate/v1','release':args.release,'verify_mode':args.verify,'hash_workers':args.hash_workers,'preflight':pre,'same_path_inventory':True,'reports':reports,'ok':all(r['seven_zip_test_ok'] and (args.verify=='quick' or r['extraction_exact']) for r in reports.values())}
    args.output_dir.mkdir(parents=True,exist_ok=True); (args.output_dir/args.report_name).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0 if report['ok'] else 1
if __name__=='__main__': raise SystemExit(main())

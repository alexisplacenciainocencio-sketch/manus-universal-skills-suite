# Referencia · Esquema mínimo de ficha

Campos mínimos: `identity`, `name`, `url`, `kind`, `category`, `status`, `certainty`, `evidence`, `license`, `version`, `updated_at`, `description`, `limits`, `risk`, `origin`, `platform`, `recommendation`, `family_code`, `source_role`, `function_detail`, `functional_fit`, `setup_and_compatibility`, `links` y `editorial_review`.

`links` debe contener `developer_maintainer`, `update_channel`, `repository_or_primary_source`, `direct_distribution`, `direct_distribution_kind`, `direct_distribution_check`, `default_branch`, `repository_exists_by_api` y `archived_by_api` cuando esos datos estén disponibles.

# Perfiles de rendimiento y calidad

## Principio

Separar la actualización frecuente de la publicación verificable. La velocidad se obtiene reutilizando ETags y digests, no omitiendo evidencia ni históricos. Ningún perfil rápido equivale a una certificación completa del release.

## Perfiles

| Perfil | Acción | No hace | Gate mínimo |
|---|---|---|---|
| `fast` | Polling GitHub con ETags, sin assets; preflight de rutas, symlinks y permisos; digests reutilizados por `(tamaño, mtime_ns)` | No crea 7z; no sustituye auditoría profunda | Igualdad de rutas, corpus presente y reporte explícito de cobertura |
| `verify` | Todo `fast` más el validador estructural/link/evidence y cache de digests | No comprime ni extrae 7z | Conteos, 1.494 históricos, 957 registros, 851 repos/ETags, 859 metadatos vivos, secretos/rutas inseguras |
| `release` | Rehash completo sin confiar en caché; manifests; 7z sólido LZMA2; `7z t`; extracción y SHA por entrada; SHA exterior | No se relaja por cambios pequeños | Gate completo de ambas variantes y equivalencia regional |

## Caché de hashes

Guardar el caché fuera del árbol publicable. Para cada ruta guardar la firma `size:mtime_ns` y el SHA-256. En `fast` y `verify`, reutilizar el digest sólo si la firma coincide. Si cambia tamaño o mtime, volver a leer el archivo. En `release`, ignorar completamente la caché y recalcular todos los digests cubiertos por el manifest. Esta caché no es una prueba de integridad del release; sólo evita lecturas repetidas durante el trabajo intermedio.

## Sincronización GitHub

Conservar ETags por repositorio y por release. Registrar contadores `200`, `304`, errores, estado de rate limit y corte UTC. Reintentar únicamente errores transitorios con backoff acotado. No descargar assets, ejecutar código de terceros ni escribir tokens. Omitir la escritura del catálogo únicamente cuando no haya cambios semánticos y ya exista el destino; mantener ledger, mapa y estado observables.

## Política de compresión

`fast` y `verify` generan reportes, no 7z. Sólo `release` recrea contenedores; por ello, una corrección de documentación no dispara compresión repetida durante cada iteración. El gate final conserva `7z a -t7z -mx=9 -m0=lzma2 -md=64m -mmt=on -ms=on`, `7z t`, extracción temporal, comparación exacta y SHA-256 exterior. No paralelizar por defecto los dos archivos grandes: medir antes, porque ambos compiten por I/O y memoria.

## Límites honestos

Una respuesta `ok` de `fast` significa que el preflight y el inventario incremental pasaron; no significa que todos los contenidos sean seguros o que un 7z sea íntegro. Una respuesta `ok` de `verify` añade validación estructural, pero la publicación sólo es válida después de `release` y de conservar sus reportes.

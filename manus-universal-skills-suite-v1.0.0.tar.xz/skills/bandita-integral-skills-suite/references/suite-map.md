# Mapa de la suite integral

La suite se activa desde `SKILL.md` y organiza el flujo completo en cinco mega-habilidades. La primera investiga y clasifica evidencia; la segunda enriquece y deduplica fichas; la tercera genera variantes `do` y `us`; la cuarta gobierna seguridad, linting y CI/CD; la quinta genera manifests, paquetes 7z y pruebas de extracción.

| Nivel | Recurso | Responsabilidad principal |
|---|---|---|
| Orquestador | `SKILL.md` | Seleccionar el flujo y conservar las invariantes |
| Mega 1 | `mega/mega-scan-evidence.md` | Descubrir fuentes y registrar evidencia |
| Mega 2 | `mega/mega-catalog-enrichment.md` | Fusionar, enriquecer y clasificar el catálogo |
| Mega 3 | `mega/mega-regional-localization.md` | Crear salidas regionales gemelas |
| Mega 4 | `mega/mega-governance-security-ci.md` | Aplicar gobernanza, seguridad y CI/CD |
| Mega 5 | `mega/mega-release-packaging.md` | Validar, manifestar, comprimir y entregar |

Las subhabilidades son unidades más pequeñas que pueden invocarse por separado: descubrimiento de fuentes; ledger de evidencia; verificación de rutas; enriquecimiento de fichas; localización regional; equivalencia y deduplicación; seguridad/linting/CI; y validación de paquetes.

## Secuencia recomendada

`source-discovery` → `evidence-ledger` → `link-route-verification` → `record-enrichment` → `regional-localization` → `equivalence-deduplication` → `security-lint-ci` → `package-validation`.

## Regla de detención

Detenerse si falta una fuente primaria, si una variante tiene rutas distintas, si aparece un secreto, si un script falla el linter o si el archivo 7z no coincide con el árbol fuente. No corregir una discrepancia ocultándola ni sustituir un corpus integral por un overlay reducido.

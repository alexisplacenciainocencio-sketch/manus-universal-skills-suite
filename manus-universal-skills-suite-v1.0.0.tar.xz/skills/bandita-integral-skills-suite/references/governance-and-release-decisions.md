# Referencia · Decisiones de gobernanza

Crear copia de trabajo; conservar la fuente y los históricos. No publicar en GitHub ni modificar repositorios reales sin autorización explícita. Usar versión, corte de evidencia, manifest, validación, hash exterior y plan de rollback. Si falla la equivalencia, el secreto, el linter o la extracción, detener la entrega.

Registrar excepciones humanas, licencia pendiente, artefactos no ejecutados y límites de traducción. Una entrega verificable debe permitir reconstruir qué se hizo y revertir la capa vigente sin perder entradas anteriores.

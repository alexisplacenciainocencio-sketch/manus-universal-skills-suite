# Referencia · Evidencia y enlaces

Usar esta referencia cuando una ficha tenga anuncios, capturas, rutas técnicas o estados contradictorios. La jerarquía práctica es: metadatos primarios del repositorio/release; README y LICENSE; documentación del mantenedor; canales oficiales; anuncios comunitarios; capturas y agregadores. Las fuentes inferiores pueden registrar una señal, pero no elevarla a confirmación primaria.

Nunca confundir que una URL responda con que el recurso sea seguro, compatible, autorizado o mantenido. Mantener los cuatro roles de enlace y registrar qué se observó realmente.

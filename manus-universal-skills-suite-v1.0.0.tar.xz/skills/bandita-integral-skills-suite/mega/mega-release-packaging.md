# Mega-habilidad 5 · Release reproducible y entrega 7z

Usar al finalizar. Ejecutar primero el validador de equivalencia y sólo empaquetar árboles que tengan el mismo inventario. Generar un manifest SHA-256 por variante, excluyendo el propio manifest y `validation_*.json` de cualquier profundidad para evitar autorreferencia; mantener esos controles dentro del archivo 7z.

Usar `7z a -t7z -mx=9 -m0=lzma2 -md=64m -mmt=on -ms=on`. Después ejecutar `7z t`, extraer a un directorio temporal y comparar rutas, tamaños y SHA-256 de todas las entradas cubiertas por el manifest. Calcular SHA-256 exterior de cada 7z. Entregar paquetes, manifests, auditorías, validación de extracción, resumen y límites.

No reemplazar un paquete integral por un overlay reducido. El resumen debe indicar conteos, tamaño sin comprimir, archivos históricos, registros vigentes, fuentes nuevas, hashes y cualquier límite de localización. Leer `subskills/package-validation.md` y `references/packaging-and-manifests.md`.

# Mega-habilidad 1 · Escáner primario y cultura de evidencia

Usar para renovar el panorama sin limitarse al corpus existente. Comenzar con búsquedas amplias; convertir cada candidato en una hipótesis, no en un hecho. Abrir el repositorio o documentación primaria, leer README, LICENSE, releases, ramas y assets, y guardar un registro con URL, fecha, versión, commit, plataforma, actividad y límites.

Separar estrictamente **disponibilidad observada**, **seguridad**, **compatibilidad**, **continuidad**, **licencia** y **autorización del contenido**. Si una captura, anuncio o índice contradice el README o los metadatos, conservar ambas señales y marcar la confirmación pendiente. No descargar ni ejecutar APKs para “probar” una ficha; verificar hashes, firmas y permisos de forma documental.

Entregar un ledger de evidencia, un inventario de fuentes, una lista de candidatos descartados y una tabla de cambios desde el corte anterior. Leer `subskills/source-discovery.md` y `subskills/evidence-ledger.md`.

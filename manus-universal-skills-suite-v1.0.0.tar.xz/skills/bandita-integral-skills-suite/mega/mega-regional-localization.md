# Mega-habilidad 3 · Localización regional gemela

Usar para generar las variantes `do` y `us` con la misma topología. Copiar la base histórica a dos árboles independientes y aplicar overlays regionales actuales. Mantener idénticos nombres de rutas, identidades, URLs técnicas, versiones, ramas, hashes de binarios y controles; localizar títulos, párrafos, advertencias, recomendaciones y convenciones editoriales.

Declarar explícitamente si los históricos se preservan literalmente por procedencia y rollback. No afirmar traducción total si sólo se tradujo la capa vigente. En español dominicano conservar claridad comunitaria, ortografía y unidades regionales; en inglés usar convenciones estadounidenses sin traducir nombres propios, URLs, assets, versiones, ramas o comandos.

Comparar rutas antes del empaquetado y fallar si una variante tiene archivos extra, faltantes o nombres regionales no equivalentes. Leer `subskills/regional-localization.md` y `subskills/equivalence-deduplication.md`.

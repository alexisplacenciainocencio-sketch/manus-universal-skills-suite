# Mega-habilidad 4 · Gobernanza, seguridad y CI/CD

Usar para blindar el proceso de construcción y actualización. Crear copia de trabajo, registrar fuente y rollback, prohibir publicación no autorizada y revisar que ningún archivo contenga credenciales, cookies, tokens, claves, keystores o datos privados. No ejecutar código de terceros ni APKs durante la auditoría.

Ejecutar el linter AST de los scripts, compilar módulos, detectar `eval`, `exec`, `os.system`, `shell=True`, imports peligrosos, symlinks, `..`, archivos world-writable y patrones de secretos. En CI usar checkout de sólo lectura, permisos mínimos, `pull_request` en código no confiable, sin `pull_request_target` para ejecutar cambios externos, sin shell construido desde entrada, y conservar JSON como artefacto no sensible.

Permitir excepciones de symlink o permisos sólo mediante configuración explícita, documentada y revisada. Leer `subskills/security-lint-ci.md` y `references/security-and-rollback.md`.

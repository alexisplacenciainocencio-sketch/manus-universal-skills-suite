# Mega-habilidad 2 · Forja y enriquecimiento del catálogo

Usar para fusionar el corpus heredado con novedades sin perder registros. Normalizar identidad por URL canónica o repositorio; deduplicar sólo cuando la equivalencia técnica y editorial esté demostrada. Conservar forks, mirrors, extensiones, plugins, parsers, servidores y clientes separados cuando tengan mantenedores, rutas o ciclos distintos.

Para cada ficha redactar función concreta, categoría, plataforma, requisitos, evolución, versión observada, licencia, estado, evidencia, riesgos, compatibilidad, límites, recomendación condicionada y procedimiento de backup/rollback. Mantener cuatro enlaces: desarrollador/mantenedor, canal de actualización, repositorio/fuente primaria y distribución directa. No usar una tabla acumulativa como sustituto de la descripción narrativa.

Registrar conteos antes y después, identidades agregadas, fusionadas y rechazadas. Leer `subskills/record-enrichment.md`, `subskills/link-route-verification.md` y `references/catalog-entry-schema.md`.
